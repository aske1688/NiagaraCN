#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"
#include "Internationalization/ILocalizedTextSource.h"
#include "Framework/MultiBox/MultiBoxExtender.h"
#include "Containers/Ticker.h"

class FNiagaraCNModule : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	static FNiagaraCNModule& Get();
	static bool IsEnabled();
	static void SetEnabled(bool bEnable);

private:
	void RegisterToolbarToggle();
	void BuildDictionary();
	void RegisterTextSource();

	// Stack-entry-level translation via AlternateDisplayName system
	void StartStackEntryScan();
	bool TranslateAllStackEntries();
	void RestoreAllStackEntries();

	static bool bEnabled;
	TMap<FString, FString> EnToZh;
	TSharedPtr<ILocalizedTextSource> TextSource;

	TSharedPtr<FExtender> NiagaraToolbarExtender;
};
