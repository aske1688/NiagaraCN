#include "NiagaraCNModule.h"
#include "Internationalization/TextLocalizationManager.h"
#include "ToolMenus.h"
#include "Styling/AppStyle.h"
#include "NiagaraEditorModule.h"
#include "NiagaraStackEditorData.h"
#include "ViewModels/Stack/NiagaraStackViewModel.h"
#include "ViewModels/Stack/NiagaraStackEntry.h"
#include "ViewModels/Stack/NiagaraStackFunctionInput.h"
#include "UObject/UnrealType.h"

DEFINE_LOG_CATEGORY_STATIC(LogNiagaraCN, Log, All);
#define LOCTEXT_NAMESPACE "FNiagaraCNModule"

IMPLEMENT_MODULE(FNiagaraCNModule, NiagaraCN)

static FTSTicker::FDelegateHandle GStackEntryScanHandle;

bool FNiagaraCNModule::bEnabled = true;

// ============================================================
//  Custom ILocalizedTextSource — intercepts at FText level
//  Provides Chinese translations as "en" localized data.
// ============================================================
class FNiagaraCNTextSource : public ILocalizedTextSource
{
public:
	explicit FNiagaraCNTextSource(const TMap<FString,FString>& InDict)
		: Dict(InDict)
	{}

	virtual int32 GetPriority() const override
	{
		return ELocalizedTextSourcePriority::Lowest;
	}

	virtual bool GetNativeCultureName(const ELocalizedTextSourceCategory InCategory, FString& OutNativeCultureName) override
	{
		OutNativeCultureName = TEXT("en");
		return true;
	}

	virtual void GetLocalizedCultureNames(const ELocalizationLoadFlags InLoadFlags, TSet<FString>& OutLocalizedCultureNames) override
	{
		OutLocalizedCultureNames.Add(TEXT("en"));
	}

	virtual void LoadLocalizedResources(const ELocalizationLoadFlags InLoadFlags, TArrayView<const FString> InPrioritizedCultures, FTextLocalizationResource& InOutNativeResource, FTextLocalizationResource& InOutLocalizedResource) override
	{
		if (!bModuleEnabled) return;
		if (InOutNativeResource.Entries.Num() == 0) return;

		int32 MatchCount = 0;
		for (const auto& Pair : InOutNativeResource.Entries)
		{
			const FString KeyStr = Pair.Key.GetKey().ToString();
			const FString* Zh = Dict.Find(KeyStr);
			if (!Zh && Pair.Value.LocalizedString.IsValid())
			{
				Zh = Dict.Find(*Pair.Value.LocalizedString);
			}
			if (Zh)
			{
				InOutLocalizedResource.AddEntry(
					Pair.Key.GetNamespace(),
					Pair.Key.GetKey(),
					Pair.Value.SourceStringHash,
					*Zh,
					0
				);
				MatchCount++;
			}
		}
		UE_LOG(LogNiagaraCN, Log, TEXT("FText管道: NativeEntries=%d, Matched=%d"),
			InOutNativeResource.Entries.Num(), MatchCount);
	}

	static void SetEnabled(bool bEnable) { bModuleEnabled = bEnable; }

private:
	TMap<FString,FString> Dict;
	static bool bModuleEnabled;
};

bool FNiagaraCNTextSource::bModuleEnabled = true;

// ============================================================
//  Dictionary
// ============================================================
static const TCHAR* RawPairs[] = {
	TEXT("Calculate Mass and Rotational Inertia by Volume"), TEXT("按体积计算质量和旋转惯性"),
	TEXT("Calculate Size and Rotational Inertia by Volume"), TEXT("按体积计算尺度和旋转惯性"),
	TEXT("Update MS Vertex Animation Tools Morph Targets"), TEXT("更新 MS 顶点动画工具变形目标"),
	TEXT("Spawn MS Vertex Animation Tools Morph Target"), TEXT("生成 MS 顶点动画工具变换目标"),
	TEXT("Calculate Mass and Rotational Inertia by Mass"), TEXT("按质量计算质量和旋转惯性"),
	TEXT("Maintain a Set Distance Between Two Points"), TEXT("两点之间维持设定距离"),
	TEXT("Update Velocity on Mass Change"), TEXT("质量变化时更新速度"),
	TEXT("Add Rotational Velocity"), TEXT("添加旋转速度"),
	TEXT("Generate Grid Ribbon IDs"), TEXT("生成网格条带 ID"),
	TEXT("Time Based State Machine"), TEXT("基于时间状态机"),
	TEXT("Find Kinetic and Potential Energy"), TEXT("查找动能和势能"),
	TEXT("Align Particles with Collision Plane"), TEXT("粒子与碰撞平面对齐"),
	TEXT("Kill Particles in Volume"), TEXT("去除体积中的粒子"),
	TEXT("Maintain in Camera Particle Scale"), TEXT("保持摄像机粒子比例"),
	TEXT("Sample Pseudo Volume Texture"), TEXT("取样伪体积纹理"),
	TEXT("Sample Skeletal Mesh Surface"), TEXT("采样骨架网格体表面"),
	TEXT("Sample Skeletal Mesh Skeleton"), TEXT("采样骨架网格体骨架"),
	TEXT("Skeletal Mesh Skeleton Location"), TEXT("骨架网格体骨架位置"),
	TEXT("Generate Location Events"), TEXT("生成位置事件"),
	TEXT("Generate Collision Event"), TEXT("生成碰撞事件"),
	TEXT("Generate Death Event"), TEXT("生成死亡事件"),
	TEXT("Skeletal Mesh Location"), TEXT("骨架网格体位置"),
	TEXT("Static Mesh Location"), TEXT("静态网格体位置"),
	TEXT("World Aligned Texture Sample"), TEXT("场景对齐纹理取样"),
	TEXT("Sub UV Texture Sample"), TEXT("子 UV 纹理取样"),
	TEXT("Calculate Accurate Velocity"), TEXT("计算准确速度"),
	TEXT("Preview Scene Settings"), TEXT("预览场景设置"),
	TEXT("Emitter Frame Counter"), TEXT("发射器帧计数器"),
	TEXT("Attribute Spreadsheet"), TEXT("属性表"),
	TEXT("Dynamic Material Parameters"), TEXT("动态材质参数"),
	TEXT("Simulation Stage"), TEXT("模拟阶段"),
	TEXT("Static Switch"), TEXT("静态开关"),
	TEXT("Stack Context"), TEXT("栈上下文"),
	TEXT("Niagara Message Log"), TEXT("Niagara 消息日志"),
	TEXT("Niagara Editor"), TEXT("Niagara 编辑器"),
	TEXT("Niagara System"), TEXT("Niagara 系统"),
	TEXT("Niagara Emitter"), TEXT("Niagara 发射器"),
	TEXT("Niagara Log"), TEXT("Niagara 日志"),
	TEXT("Generated Code"), TEXT("生成代码"),
	TEXT("Legacy Parameters"), TEXT("旧版参数"),
	TEXT("Parameter Map"), TEXT("参数映射"),
	TEXT("Execution State"), TEXT("执行状态"),
	TEXT("Inactive Response"), TEXT("非活跃响应"),

	// Renderers
	TEXT("Component Renderer"), TEXT("组件渲染器"),
	TEXT("Light Renderer"), TEXT("光源渲染器"),
	TEXT("Mesh Renderer"), TEXT("网格体渲染器"),
	TEXT("Ribbon Renderer"), TEXT("条带渲染器"),
	TEXT("Sprite Renderer"), TEXT("Sprite 渲染器"),
	TEXT("Decal Renderer"), TEXT("贴花渲染器"),
	TEXT("Render Visibility Tag"), TEXT("渲染可见性标签"),
	TEXT("Material Parameter Bind"), TEXT("材质参数绑定"),
	TEXT("UV Scale & Offset"), TEXT("UV 缩放与偏移"),
	TEXT("Camera Offset"), TEXT("摄像机偏移"),
	TEXT("SubUV Animation"), TEXT("子 UV 动画"),
	TEXT("Sprite Rotation Rate"), TEXT("Sprite 旋转率"),
	TEXT("Dynamic Parameter"), TEXT("动态参数"),
	TEXT("Facing Mode"), TEXT("朝向模式"),
	TEXT("Sort Mode"), TEXT("排序模式"),
	TEXT("Blend Mode"), TEXT("混合模式"),
	TEXT("Pivot Offset"), TEXT("锚点偏移"),
	TEXT("Sub UV"), TEXT("子 UV"),

	// Stack Groups
	TEXT("Particle Spawn Group"), TEXT("粒子生成组"),
	TEXT("Particle Update Group"), TEXT("粒子更新组"),
	TEXT("Emitter Spawn Group"), TEXT("发射器生成组"),
	TEXT("Emitter Update Group"), TEXT("发射器更新组"),
	TEXT("System Spawn Group"), TEXT("系统生成组"),
	TEXT("System Update Group"), TEXT("系统更新组"),
	TEXT("Render Group"), TEXT("渲染组"),
	TEXT("Event Handler"), TEXT("事件处理器"),

	// Spawn modules
	TEXT("Spawn Burst Instantaneous"), TEXT("生成即时迸发"),
	TEXT("Spawn Particles in Grid"), TEXT("在网格中生成粒子"),
	TEXT("Spawn from Chaos"), TEXT("从 Chaos 中生成"),
	TEXT("Event Driven Spawn"), TEXT("事件驱动生成"),
	TEXT("Determine Spawn Count"), TEXT("确定生成数量"),
	TEXT("Spawn Per Unit"), TEXT("每单位生成"),
	TEXT("Spawn Per Frame"), TEXT("每帧生成"),
	TEXT("Spawn Rate"), TEXT("生成速率"),
	TEXT("Spawn Burst"), TEXT("爆发生成"),
	TEXT("Spawn Beam"), TEXT("生成光束"),
	TEXT("Spawn Info"), TEXT("生成信息"),

	// Initialize
	TEXT("Initialize Mesh Reproduction Sprite"), TEXT("初始化网格体复制 Sprite"),
	TEXT("Update Mesh Reproduction Sprite"), TEXT("更新网格体复制 Sprite"),
	TEXT("Initialize Particle"), TEXT("初始化粒子"),
	TEXT("Initialize Ribbon"), TEXT("初始化条带"),
	TEXT("Beam Emitter Setup"), TEXT("光束发射器设置"),

	// Location
	TEXT("Rotate Around Point"), TEXT("绕点旋转"),
	TEXT("Box Location"), TEXT("盒体位置"),
	TEXT("Cone Location"), TEXT("锥体位置"),
	TEXT("Cylinder Location"), TEXT("圆柱体位置"),
	TEXT("Grid Location"), TEXT("网格位置"),
	TEXT("Jitter Position"), TEXT("抖动位置"),
	TEXT("Sphere Location"), TEXT("球体位置"),
	TEXT("System Location"), TEXT("系统位置"),
	TEXT("Torus Location"), TEXT("圆环位置"),
	TEXT("Mesh Location"), TEXT("网格体位置"),

	// Velocity
	TEXT("Add Velocity from Point"), TEXT("添加点中速度"),
	TEXT("Add Velocity in Cone"), TEXT("在锥体中添加速度"),
	TEXT("Align Velocity to Random Axis"), TEXT("将速度对齐随机轴"),
	TEXT("Static Mesh Velocity"), TEXT("静态网格体速度"),
	TEXT("Solve Forces and Velocity"), TEXT("解算力与速度"),
	TEXT("Inherit Velocity"), TEXT("继承速度"),
	TEXT("Scale Velocity"), TEXT("缩放速度"),
	TEXT("Vortex Velocity"), TEXT("旋涡速度"),
	TEXT("Velocity Cone"), TEXT("锥形速度"),
	TEXT("Add Velocity"), TEXT("添加速度"),

	// Force
	TEXT("Line Attraction Force"), TEXT("线吸引力"),
	TEXT("Point Attraction Force"), TEXT("点引力"),
	TEXT("Mesh Rotation Force"), TEXT("网格体旋转力"),
	TEXT("Vector Noise Force"), TEXT("向量噪点力"),
	TEXT("Acceleration Force"), TEXT("加速力"),
	TEXT("Apply Initial Forces"), TEXT("施加初始力"),
	TEXT("Curl Noise Force"), TEXT("旋度噪点力"),
	TEXT("Gravity Force"), TEXT("重力"),
	TEXT("Rotational Force"), TEXT("旋转力"),
	TEXT("Point Attraction"), TEXT("点引力"),
	TEXT("Linear Force"), TEXT("线性力"),
	TEXT("Vortex Force"), TEXT("旋涡力"),
	TEXT("Radial Force"), TEXT("径向力"),
	TEXT("Spring Force"), TEXT("弹簧力"),
	TEXT("Wind Force"), TEXT("风力"),
	TEXT("Point Force"), TEXT("点力"),
	TEXT("Limit Force"), TEXT("限制力"),
	TEXT("Drag"), TEXT("阻力"),

	// Constraint
	TEXT("Pendulum Constraint"), TEXT("钟摆约束"),
	TEXT("Pendulum Setup"), TEXT("钟摆设置"),

	// Color
	TEXT("Scale Color by Speed"), TEXT("按速度缩放颜色"),
	TEXT("Color by Speed"), TEXT("速度着色"),
	TEXT("Color Mode"), TEXT("颜色模式"),
	TEXT("Color Output"), TEXT("颜色输出"),
	TEXT("Scale Color"), TEXT("缩放颜色"),
	TEXT("Linear Color"), TEXT("线性颜色"),

	// Size
	TEXT("Scale Mesh Size by Speed"), TEXT("按速度缩放网格体尺寸"),
	TEXT("Scale Sprite Size by Speed"), TEXT("按速度缩放 Sprite 尺寸"),
	TEXT("Scale Mesh Size"), TEXT("缩放网格体尺寸"),
	TEXT("Scale Sprite Size"), TEXT("缩放 Sprite 尺寸"),
	TEXT("Beam Width Scale"), TEXT("光束宽度缩放"),
	TEXT("Ribbon Width Scale"), TEXT("条带宽度"),
	TEXT("Size by Speed"), TEXT("速度大小"),
	TEXT("Beam Width"), TEXT("光束宽度"),

	// Orientation
	TEXT("Align Sprite to Mesh Orientation"), TEXT("将 Sprite 与网格体朝向对齐"),
	TEXT("Initial Mesh Orientation"), TEXT("初始网格体朝向"),
	TEXT("Orient Mesh to Vector"), TEXT("将网格体朝向向量"),
	TEXT("Update Mesh Orientation"), TEXT("更新网格体朝向"),

	// Collision
	TEXT("Collision Event"), TEXT("碰撞事件"),
	TEXT("Ray Collision"), TEXT("射线碰撞"),
	TEXT("Depth Collision"), TEXT("深度碰撞"),
	TEXT("Collision"), TEXT("碰撞"),

	// Kill
	TEXT("Kill Particles"), TEXT("去除粒子"),

	// Events
	TEXT("Location Event"), TEXT("位置事件"),
	TEXT("Death Event"), TEXT("死亡事件"),
	TEXT("Generate Event"), TEXT("生成事件"),
	TEXT("Event Payload"), TEXT("事件载荷"),

	// Math
	TEXT("Lerp Particle Attributes"), TEXT("插值粒子属性"),
	TEXT("Recreate Camera Projection"), TEXT("重新创建摄像机投射"),
	TEXT("Temporal Lerp Float"), TEXT("临时插值浮点"),
	TEXT("Temporal Lerp Vector"), TEXT("临时插值向量"),
	TEXT("Cross Product"), TEXT("叉积"),
	TEXT("Dot Product"), TEXT("点积"),
	TEXT("Smooth Step"), TEXT("平滑阶跃"),
	TEXT("Remap Range"), TEXT("范围重映射"),
	TEXT("Color Curves"), TEXT("颜色曲线"),
	TEXT("Size Curves"), TEXT("大小曲线"),
	TEXT("Curve Editor"), TEXT("曲线编辑器"),
	TEXT("Cone Mask"), TEXT("锥体遮罩"),
	TEXT("Normalize"), TEXT("归一化"),
	TEXT("Saturate"), TEXT("饱和钳制"),
	TEXT("Distance"), TEXT("距离"),
	TEXT("Length"), TEXT("长度"),
	TEXT("Floor"), TEXT("向下取整"),
	TEXT("Cosine"), TEXT("余弦"),
	TEXT("Sine"), TEXT("正弦"),
	TEXT("Ceil"), TEXT("向上取整"),
	TEXT("Frac"), TEXT("小数部分"),
	TEXT("Lerp"), TEXT("线性插值"),
	TEXT("Clamp"), TEXT("钳制"),

	// Texture
	TEXT("Sample Texture"), TEXT("取样纹理"),
	TEXT("Texture Data"), TEXT("纹理数据"),

	// Vector Field
	TEXT("Apply Vector Field"), TEXT("应用向量场"),
	TEXT("Sample Vector Field"), TEXT("取样向量场"),
	TEXT("Vector Field"), TEXT("向量场"),

	// Chaos / Audio
	TEXT("Apply Chaos Data"), TEXT("应用混沌数据"),
	TEXT("Audio Data"), TEXT("音频数据"),

	// State / Lifetime
	TEXT("Increment Over Time"), TEXT("随时间增量"),
	TEXT("Particle State"), TEXT("粒子状态"),
	TEXT("Emitter State"), TEXT("发射器状态"),
	TEXT("System State"), TEXT("系统状态"),
	TEXT("Update Age"), TEXT("更新年龄"),
	TEXT("Do Once"), TEXT("执行一次"),
	TEXT("Lifetime"), TEXT("生命周期"),

	// System / Emitter core
	TEXT("System Overview"), TEXT("系统概览"),
	TEXT("Emitter Summary"), TEXT("发射器摘要"),
	TEXT("Selected Emitter"), TEXT("当前发射器"),
	TEXT("Selected Details"), TEXT("选定细节"),
	TEXT("System Details"), TEXT("系统细节"),
	TEXT("Script Details"), TEXT("脚本细节"),
	TEXT("Script Stats"), TEXT("脚本统计数据"),
	TEXT("Scratch Pad"), TEXT("暂存区"),
	TEXT("Node Graph"), TEXT("节点图表"),
	TEXT("Particle Spawn"), TEXT("粒子生成"),
	TEXT("Particle Death"), TEXT("粒子消亡"),
	TEXT("Particle Update"), TEXT("粒子更新"),
	TEXT("Emitter Spawn"), TEXT("发射器生成"),
	TEXT("Emitter Update"), TEXT("发射器更新"),
	TEXT("System Spawn"), TEXT("系统生成"),
	TEXT("System Update"), TEXT("系统更新"),

	// Execution States
	TEXT("InactiveClear"), TEXT("非活跃清除"),
	TEXT("Inactive"), TEXT("非活跃"),
	TEXT("Active"), TEXT("活跃"),
	TEXT("Complete"), TEXT("完成"),

	// Namespaces
	TEXT("Namespace"), TEXT("命名空间"),
	TEXT("Transient"), TEXT("瞬态"),
	TEXT("Particles"), TEXT("粒子"),
	TEXT("Emitter"), TEXT("发射器"),
	TEXT("System"), TEXT("系统"),
	TEXT("Engine"), TEXT("引擎"),
	TEXT("User"), TEXT("用户"),

	// Data Types
	TEXT("Niagara ID"), TEXT("Niagara 标识"),
	TEXT("Half Vector"), TEXT("半精度向量"),
	TEXT("Quaternion"), TEXT("四元数"),
	TEXT("Vector 2D"), TEXT("二维向量"),
	TEXT("Vector 4"), TEXT("四维向量"),
	TEXT("Position"), TEXT("位置"),
	TEXT("Vector"), TEXT("三维向量"),
	TEXT("Half"), TEXT("半精度浮点"),
	TEXT("float"), TEXT("浮点数"),
	TEXT("int32"), TEXT("整数"),
	TEXT("bool"), TEXT("布尔"),

	// Data Interfaces
	TEXT("Skeletal Mesh Data"), TEXT("骨骼网格体数据"),
	TEXT("Static Mesh Data"), TEXT("静态网格体数据"),
	TEXT("Neighbor Grid 3D"), TEXT("邻居网格 3D"),
	TEXT("Curl Noise Data"), TEXT("旋度噪声数据"),
	TEXT("Occlusion Query"), TEXT("遮挡查询"),
	TEXT("GBuffer Data"), TEXT("GBuffer 数据"),
	TEXT("Spline Data"), TEXT("样条线数据"),
	TEXT("Data Interfaces"), TEXT("数据接口"),
	TEXT("Data Interface"), TEXT("数据接口"),
	TEXT("Grid 3D"), TEXT("三维网格"),
	TEXT("Grid 2D"), TEXT("二维网格"),

	// GPU / Simulation
	TEXT("GPU Data Interface"), TEXT("GPU 数据接口"),
	TEXT("GPU Simulation"), TEXT("GPU 模拟"),
	TEXT("CPU Simulation"), TEXT("CPU 模拟"),
	TEXT("Custom HLSL"), TEXT("自定义 HLSL"),
	TEXT("Iteration Count"), TEXT("迭代次数"),

	// Performance / Bounds
	TEXT("Fixed Bounds"), TEXT("固定包围盒"),
	TEXT("Particle Count"), TEXT("粒子计数"),
	TEXT("Max Particles"), TEXT("最大粒子数"),
	TEXT("LOD Distance"), TEXT("LOD 距离"),
	TEXT("Scalability"), TEXT("可扩展性"),
	TEXT("Significance"), TEXT("重要性"),
	TEXT("Bounds"), TEXT("包围盒"),

	// Noise / Random
	TEXT("Voronoi Noise"), TEXT("Voronoi 噪声"),
	TEXT("Perlin Noise"), TEXT("柏林噪声"),
	TEXT("Curl Noise"), TEXT("旋度噪声"),
	TEXT("Random Range"), TEXT("随机范围"),
	TEXT("Random Float"), TEXT("随机浮点"),
	TEXT("Random Vector"), TEXT("随机向量"),
	TEXT("Noise"), TEXT("噪声"),
	TEXT("Seed"), TEXT("随机种子"),

	// Common modules / actions
	TEXT("Add Velocity in Cone"), TEXT("锥形添加速度"),
	TEXT("Add Module"), TEXT("添加模块"),
	TEXT("Remove Module"), TEXT("移除模块"),
	TEXT("Enable Module"), TEXT("启用模块"),
	TEXT("Debug Draw"), TEXT("调试绘制"),
	TEXT("Set Variable"), TEXT("设置变量"),
	TEXT("Map Get"), TEXT("映射获取"),
	TEXT("Map Set"), TEXT("映射设置"),
	TEXT("Expression"), TEXT("表达式"),
	TEXT("Interpolation"), TEXT("插值生成"),
	TEXT("Module"), TEXT("模块"),
	TEXT("Function"), TEXT("函数"),
	TEXT("Input"), TEXT("输入"),
	TEXT("Output"), TEXT("输出"),

	// Parameters: Particles.xxx
	TEXT("Particles.NormalizedAge"), TEXT("粒子.归一化年龄"),
	TEXT("Particles.SpriteSize"), TEXT("粒子.Sprite 大小"),
	TEXT("Particles.Lifetime"), TEXT("粒子.生命周期"),
	TEXT("Particles.Velocity"), TEXT("粒子.速度"),
	TEXT("Particles.Position"), TEXT("粒子.位置"),
	TEXT("Particles.Scale"), TEXT("粒子.缩放"),
	TEXT("Particles.Mass"), TEXT("粒子.质量"),
	TEXT("Particles.Color"), TEXT("粒子.颜色"),
	TEXT("Particles.Age"), TEXT("粒子.年龄"),
	TEXT("Particles.ID"), TEXT("粒子.ID"),

	// Parameters: Emitter.xxx
	TEXT("Emitter.NumParticles"), TEXT("发射器.粒子数"),
	TEXT("Emitter.LoopedAge"), TEXT("发射器.循环年龄"),
	TEXT("Emitter.Age"), TEXT("发射器.运行时间"),

	// Parameters: Engine.xxx
	TEXT("Engine.Owner.Rotation"), TEXT("引擎.拥有者.旋转"),
	TEXT("Engine.Owner.Position"), TEXT("引擎.拥有者.位置"),
	TEXT("Engine.DeltaTime"), TEXT("引擎.帧间隔"),
	TEXT("Engine.Time"), TEXT("引擎.时间"),

	// Parameters: System.xxx
	TEXT("System.ExecutionState"), TEXT("系统.执行状态"),
	TEXT("System.NumEmitters"), TEXT("系统.发射器数量"),
	TEXT("System.Age"), TEXT("系统.运行时间"),

	// Editor UI panels
	TEXT("Engine Provided"), TEXT("引擎提供"),
	TEXT("Modules Locals"), TEXT("模块本地值"),
	TEXT("Module Inputs"), TEXT("模块输入"),
	TEXT("Particle Attributes"), TEXT("粒子属性"),
	TEXT("Emitter Attributes"), TEXT("发射器属性"),
	TEXT("System Attributes"), TEXT("系统属性"),
	TEXT("Preview"), TEXT("预览"),
	TEXT("Timeline"), TEXT("时间轴"),
	TEXT("Toolbar"), TEXT("工具栏"),
	TEXT("Viewport"), TEXT("视口"),
	TEXT("Parameters"), TEXT("参数"),
	TEXT("Properties"), TEXT("属性"),
	TEXT("Attributes"), TEXT("属性"),
	TEXT("Settings"), TEXT("设置"),
	TEXT("Details"), TEXT("细节"),
	TEXT("General"), TEXT("常规"),
	TEXT("Advanced"), TEXT("高级"),
	TEXT("Selection"), TEXT("选择"),
	TEXT("Alignment"), TEXT("对齐方式"),
	TEXT("Curves"), TEXT("曲线"),
	TEXT("Stats"), TEXT("统计数据"),
	TEXT("Script"), TEXT("脚本"),
	TEXT("Material"), TEXT("材质"),

	// Property names
	TEXT("Distribution"), TEXT("分布"),
	TEXT("Hue"), TEXT("色调"),
	TEXT("Saturation"), TEXT("饱和度"),
	TEXT("Value"), TEXT("明度"),
	TEXT("Alpha"), TEXT("透明度"),
	TEXT("Brightness"), TEXT("亮度"),
	TEXT("Contrast"), TEXT("对比度"),
	TEXT("Intensity"), TEXT("强度"),
	TEXT("Opacity"), TEXT("不透明度"),
	TEXT("Tint"), TEXT("色调"),
	TEXT("Override"), TEXT("覆盖"),
	TEXT("Inherit"), TEXT("继承"),
	TEXT("Radius"), TEXT("半径"),
	TEXT("Height"), TEXT("高度"),
	TEXT("Width"), TEXT("宽度"),
	TEXT("Thickness"), TEXT("厚度"),
	TEXT("Angle"), TEXT("角度"),
	TEXT("Pitch"), TEXT("俯仰角"),
	TEXT("Yaw"), TEXT("偏航角"),
	TEXT("Roll"), TEXT("翻滚角"),
	TEXT("Transform"), TEXT("变换"),
	TEXT("Location"), TEXT("位置"),
	TEXT("Rotation"), TEXT("旋转"),
	TEXT("Scale"), TEXT("缩放"),
	TEXT("Size"), TEXT("大小"),
	TEXT("Mass"), TEXT("质量"),
	TEXT("Speed"), TEXT("速度"),
	TEXT("Velocity"), TEXT("速度"),
	TEXT("Acceleration"), TEXT("加速度"),
	TEXT("Force"), TEXT("力"),
	TEXT("Gravity"), TEXT("重力"),
	TEXT("Drag Coefficient"), TEXT("阻力系数"),
	TEXT("Friction"), TEXT("摩擦力"),
	TEXT("Restitution"), TEXT("弹性系数"),
	TEXT("Damping"), TEXT("阻尼"),
	TEXT("Stiffness"), TEXT("刚度"),
	TEXT("Frequency"), TEXT("频率"),
	TEXT("Amplitude"), TEXT("振幅"),
	TEXT("Period"), TEXT("周期"),
	TEXT("Phase"), TEXT("相位"),
	TEXT("Offset"), TEXT("偏移"),
	TEXT("Range"), TEXT("范围"),
	TEXT("Minimum"), TEXT("最小值"),
	TEXT("Maximum"), TEXT("最大值"),
	TEXT("Rate"), TEXT("速率"),
	TEXT("Count"), TEXT("数量"),
	TEXT("Amount"), TEXT("数量"),
	TEXT("Weight"), TEXT("权重"),
	TEXT("Priority"), TEXT("优先级"),
	TEXT("Quality"), TEXT("质量"),
	TEXT("Resolution"), TEXT("分辨率"),
	TEXT("Precision"), TEXT("精度"),
	TEXT("Tolerance"), TEXT("容差"),
	TEXT("Threshold"), TEXT("阈值"),
	TEXT("Falloff"), TEXT("衰减"),
	TEXT("Exponent"), TEXT("指数"),
	TEXT("Multiplier"), TEXT("乘数"),
	TEXT("Divider"), TEXT("除数"),
	TEXT("Bias"), TEXT("偏差"),

	// Distribution types
	TEXT("Uniform Distribution"), TEXT("均匀分布"),
	TEXT("Gaussian Distribution"), TEXT("高斯分布"),
	TEXT("Random Distribution"), TEXT("随机分布"),
	TEXT("Constant Curve"), TEXT("常量曲线"),
	TEXT("Uniform Curve"), TEXT("均匀曲线"),
	TEXT("Random Curve"), TEXT("随机曲线"),
	TEXT("User Curve"), TEXT("用户曲线"),
	TEXT("Float from Curve"), TEXT("曲线浮点值"),

	// Dropdown values
	TEXT("Surface"), TEXT("表面"),
	TEXT("Volume"), TEXT("体积"),
	TEXT("Hemisphere"), TEXT("半球"),
	TEXT("Uniform"), TEXT("均匀"),
	TEXT("Random"), TEXT("随机"),
	TEXT("Non-Uniform"), TEXT("非均匀"),
	TEXT("Closest"), TEXT("最近"),
	TEXT("Farthest"), TEXT("最远"),
	TEXT("Highest"), TEXT("最高"),
	TEXT("Lowest"), TEXT("最低"),
	TEXT("Nearest"), TEXT("最接近"),
	TEXT("Linear"), TEXT("线性"),
	TEXT("Smooth"), TEXT("平滑"),
	TEXT("Cubic"), TEXT("三次方"),
	TEXT("Quadratic"), TEXT("二次方"),
	TEXT("Exponential"), TEXT("指数"),
	TEXT("Logarithmic"), TEXT("对数"),
	TEXT("Constant"), TEXT("常量"),
	TEXT("Curve"), TEXT("曲线"),
	TEXT("Direct"), TEXT("直接"),
	TEXT("Indirect"), TEXT("间接"),
	TEXT("Additive"), TEXT("叠加"),
	TEXT("Multiplicative"), TEXT("相乘"),
	TEXT("Replace"), TEXT("替换"),
	TEXT("Blend"), TEXT("混合"),
	TEXT("Mix"), TEXT("混合"),
	TEXT("Absolute"), TEXT("绝对"),
	TEXT("Relative"), TEXT("相对"),
	TEXT("Local"), TEXT("局部"),
	TEXT("World"), TEXT("世界"),
	TEXT("Screen"), TEXT("屏幕"),
	TEXT("Vertical"), TEXT("垂直"),
	TEXT("Horizontal"), TEXT("水平"),
	TEXT("Forward"), TEXT("前方"),
	TEXT("Backward"), TEXT("后方"),
	TEXT("Left"), TEXT("左"),
	TEXT("Right"), TEXT("右"),
	TEXT("Up"), TEXT("上"),
	TEXT("Down"), TEXT("下"),
	TEXT("Inside"), TEXT("内部"),
	TEXT("Outside"), TEXT("外部"),
	TEXT("Center"), TEXT("中心"),
	TEXT("Edge"), TEXT("边缘"),
	TEXT("Corner"), TEXT("角落"),
	TEXT("Top"), TEXT("顶部"),
	TEXT("Bottom"), TEXT("底部"),
	TEXT("Side"), TEXT("侧面"),
	TEXT("Front"), TEXT("前面"),
	TEXT("Back"), TEXT("后面"),

	// Color values
	TEXT("sRGB"), TEXT("sRGB"),
	TEXT("HSV"), TEXT("HSV"),
	TEXT("RGB"), TEXT("RGB"),
	TEXT("HSL"), TEXT("HSL"),
	TEXT("CMYK"), TEXT("CMYK"),

	// Types
	TEXT("Primitive"), TEXT("图元"),
	TEXT("Struct"), TEXT("结构体"),
	TEXT("Enum"), TEXT("枚举"),

	// Operations
	TEXT("Fade In"), TEXT("淡入"),
	TEXT("Fade Out"), TEXT("淡出"),
	TEXT("Enabled"), TEXT("已启用"),
	TEXT("Disabled"), TEXT("已禁用"),
	TEXT("Visible"), TEXT("可见"),
	TEXT("Hidden"), TEXT("隐藏"),
	TEXT("Default"), TEXT("默认"),
	TEXT("Custom"), TEXT("自定义"),
	TEXT("Duplicate"), TEXT("复制"),
	TEXT("Rename"), TEXT("重命名"),
	TEXT("Delete"), TEXT("删除"),
	TEXT("Cancel"), TEXT("取消"),
	TEXT("Export"), TEXT("导出"),
	TEXT("Import"), TEXT("导入"),
	TEXT("Compile"), TEXT("编译"),
	TEXT("Search"), TEXT("搜索"),
	TEXT("Filter"), TEXT("筛选"),
	TEXT("Apply"), TEXT("应用"),
	TEXT("Reset"), TEXT("重置"),
	TEXT("Close"), TEXT("关闭"),
	TEXT("Paste"), TEXT("粘贴"),
	TEXT("Save"), TEXT("保存"),
	TEXT("Load"), TEXT("加载"),
	TEXT("Open"), TEXT("打开"),
	TEXT("Copy"), TEXT("拷贝"),
	TEXT("Undo"), TEXT("撤销"),
	TEXT("Redo"), TEXT("重做"),
	TEXT("None"), TEXT("无"),
	TEXT("True"), TEXT("是"),
	TEXT("False"), TEXT("否"),

	nullptr
};

void FNiagaraCNModule::BuildDictionary()
{
	EnToZh.Empty();

	TArray<TPair<FString,FString>> Pairs;
	int32 i = 0;
	while (RawPairs[i])
	{
		Pairs.Add(TPair<FString,FString>(FString(RawPairs[i]).TrimStartAndEnd(), FString(RawPairs[i+1])));
		i += 2;
	}

	Pairs.Sort([](const TPair<FString,FString>& A, const TPair<FString,FString>& B)
	{
		int32 LenA = A.Key.Len();
		int32 LenB = B.Key.Len();
		if (LenA != LenB) return LenA > LenB;
		return A.Key < B.Key;
	});

	for (auto& P : Pairs)
	{
		EnToZh.Add(P.Key, P.Value);
	}

	UE_LOG(LogNiagaraCN, Log, TEXT("词典已加载：%d 条"), EnToZh.Num());
}

// ============================================================
//  Module lifecycle
// ============================================================
FNiagaraCNModule& FNiagaraCNModule::Get()
{
	return FModuleManager::LoadModuleChecked<FNiagaraCNModule>("NiagaraCN");
}

bool FNiagaraCNModule::IsEnabled()
{
	return bEnabled;
}

void FNiagaraCNModule::SetEnabled(bool bEnable)
{
	if (bEnable == bEnabled) return;
	bEnabled = bEnable;

	FNiagaraCNTextSource::SetEnabled(bEnable);

	if (bEnable)
	{
		FTextLocalizationManager::Get().RefreshResources();
		Get().TranslateAllStackEntries();
		Get().StartStackEntryScan();
	}
	else
	{
		if (GStackEntryScanHandle.IsValid())
		{
			FTSTicker::GetCoreTicker().RemoveTicker(GStackEntryScanHandle);
			GStackEntryScanHandle.Reset();
		}
		Get().RestoreAllStackEntries();
		FTextLocalizationManager::Get().RefreshResources();
	}

	UE_LOG(LogNiagaraCN, Log, TEXT("翻译%s"), bEnable ? TEXT("已启用") : TEXT("已禁用"));
}

void FNiagaraCNModule::StartupModule()
{
	BuildDictionary();
	RegisterToolbarToggle();
	RegisterTextSource();
	StartStackEntryScan();
	UE_LOG(LogNiagaraCN, Log, TEXT("Niagara 中文翻译伴侣已启动 (FText管道 + 栈条目AlternateDisplayName)"));
}

void FNiagaraCNModule::ShutdownModule()
{
	bEnabled = false;
	FNiagaraCNTextSource::SetEnabled(false);

	// CRITICAL: Remove ticker FIRST to stop any in-flight UObject iteration
	if (GStackEntryScanHandle.IsValid())
	{
		FTSTicker::GetCoreTicker().RemoveTicker(GStackEntryScanHandle);
		GStackEntryScanHandle.Reset();
	}

	// Release the text source.  FTextLocalizationManager holds its own shared
	// reference, so the object lives until the manager shuts down naturally.
	TextSource.Reset();

	// Remove toolbar extender from NiagaraEditor
	if (NiagaraToolbarExtender.IsValid())
	{
		if (FNiagaraEditorModule* NiagaraModule = FModuleManager::GetModulePtr<FNiagaraEditorModule>("NiagaraEditor"))
		{
			TSharedPtr<FExtensibilityManager> Mgr = NiagaraModule->GetToolBarExtensibilityManager();
			if (Mgr.IsValid())
			{
				Mgr->RemoveExtender(NiagaraToolbarExtender);
			}
		}
		NiagaraToolbarExtender.Reset();
	}

	// DO NOT call RestoreAllStackEntries() or RefreshResources() here.
	// During shutdown UObjects are being destroyed and iterating them will
	// crash.  Any AlternateDisplayName overrides die with the editor anyway.
}

void FNiagaraCNModule::RegisterTextSource()
{
	if (TextSource.IsValid()) return;

	TextSource = MakeShared<FNiagaraCNTextSource>(EnToZh);
	FTextLocalizationManager::Get().RegisterTextSource(TextSource.ToSharedRef(), true);
	UE_LOG(LogNiagaraCN, Log, TEXT("已注册 FText 翻译源（%d 词条）"), EnToZh.Num());
}

// ============================================================
//  Stack-entry-level translation via AlternateDisplayName
//  Uses UNiagaraStackEditorData::SetStackEntryDisplayName()
//  to set persistent alternate names, then triggers a full
//  stack refresh.  The SNiagaraStackDisplayName widget already
//  checks AlternateDisplayName before GetDisplayName().
//
//  A periodic ticker rescans for new entries (expanded nodes,
//  added modules, etc.) and translates them.
// ============================================================

// MinimalAPI classes don't export StaticClass(), so we can't use
// TObjectIterator<T> or Cast<T>(). Check class hierarchy at runtime.
static bool IsA(UObject* Obj, const TCHAR* ClassName)
{
	for (UClass* C = Obj->GetClass(); C; C = C->GetSuperClass())
	{
		if (C->GetFName() == ClassName) return true;
	}
	return false;
}

// SetStackEntryDisplayName is not DLL-exported, so we access
// StackEntryKeyToDisplayName UPROPERTY via reflection.
static void SetDisplayNameViaReflection(UNiagaraStackEditorData& EditorData, const FString& Key, const FText& Value)
{
	static FMapProperty* MapProp = nullptr;
	if (!MapProp)
	{
		FProperty* Prop = EditorData.GetClass()->FindPropertyByName(TEXT("StackEntryKeyToDisplayName"));
		MapProp = CastField<FMapProperty>(Prop);
		if (!MapProp)
		{
			UE_LOG(LogNiagaraCN, Error, TEXT("无法找到 StackEntryKeyToDisplayName 属性"));
			return;
		}
	}

	void* MapAddr = MapProp->ContainerPtrToValuePtr<void>(&EditorData);
	FScriptMapHelper MapHelper(MapProp, MapAddr);

	if (Value.IsEmptyOrWhitespace())
	{
		int32 Idx = MapHelper.FindMapIndexWithKey(&Key);
		if (Idx != INDEX_NONE)
		{
			MapHelper.RemoveAt(Idx);
		}
	}
	else
	{
		int32 Idx = MapHelper.FindMapIndexWithKey(&Key);
		if (Idx == INDEX_NONE)
		{
			Idx = MapHelper.AddDefaultValue_Invalid_NeedsRehash();
			FString* KeyPtr = (FString*)MapHelper.GetKeyPtr(Idx);
			*KeyPtr = Key;
		}
		FText* ValuePtr = (FText*)MapHelper.GetValuePtr(Idx);
		*ValuePtr = Value;
		MapHelper.Rehash();
	}

	EditorData.OnPersistentDataChanged().Broadcast();
}

// Returns true if a translation was applied
static bool ApplyTranslationsToEntry(UNiagaraStackEntry* Entry, const TMap<FString,FString>& Dict)
{
	const FString DispStr = Entry->GetDisplayName().ToString();
	if (DispStr.IsEmpty()) return false;

	TOptional<FText> AltName = Entry->GetAlternateDisplayName();
	FString AltStr = AltName.IsSet() ? AltName.GetValue().ToString() : FString();

	UNiagaraStackEditorData& EditorData = Entry->GetStackEditorData();
	const FString Key = Entry->GetStackEditorDataKey();

	// Find translation: exact match first, then substring replacement
	FString Zh;
	if (const FString* Found = Dict.Find(DispStr))
	{
		Zh = *Found;
	}
	else
	{
		FString Result = DispStr;
		bool bChanged = false;
		for (const auto& P : Dict)
		{
			if (Result.Contains(P.Key))
			{
				Result = Result.Replace(*P.Key, *P.Value);
				bChanged = true;
			}
		}
		if (bChanged) Zh = Result;
	}

	if (Zh.IsEmpty()) return false;

	// For function inputs (parameters), use SetSummaryViewDisplayName directly
	// because their RefreshChildrenInternal() does NOT call Super, so they
	// never load AlternateDisplayName from the editor data TMap.
	if (IsA(Entry, TEXT("NiagaraStackFunctionInput")))
	{
		UNiagaraStackFunctionInput* Input = static_cast<UNiagaraStackFunctionInput*>(Entry);
		FText CurrentDisplay = Input->GetDisplayName();
		if (CurrentDisplay.ToString() != Zh)
		{
			Input->SetSummaryViewDisplayName(TAttribute<FText>(FText::FromString(Zh)));
			return true;
		}
		return false;
	}

	// For regular entries, use the editor-data AlternateDisplayName approach
	if (AltStr != Zh)
	{
		SetDisplayNameViaReflection(EditorData, Key, FText::FromString(Zh));
		return true;
	}
	return false;
}

bool FNiagaraCNModule::TranslateAllStackEntries()
{
	int32 TranslatedCount = 0;

	for (TObjectIterator<UObject> It; It; ++It)
	{
		UObject* Obj = *It;
		if (!Obj || !IsA(Obj, TEXT("NiagaraStackEntry"))) continue;

		UNiagaraStackEntry* Entry = static_cast<UNiagaraStackEntry*>(Obj);
		if (Entry->IsFinalized()) continue;

		if (ApplyTranslationsToEntry(Entry, EnToZh))
		{
			TranslatedCount++;
		}
	}

	// Trigger refresh on all stack view models — only if we actually translated something new
	if (TranslatedCount > 0)
	{
		int32 VmCount = 0;
		for (TObjectIterator<UObject> It; It; ++It)
		{
			UObject* Obj = *It;
			if (!Obj || !IsA(Obj, TEXT("NiagaraStackViewModel"))) continue;

			UNiagaraStackViewModel* VM = static_cast<UNiagaraStackViewModel*>(Obj);
			if (VM->GetRootEntry() && !VM->GetRootEntry()->IsFinalized())
			{
				VM->RequestRefreshDeferred();
				VmCount++;
			}
		}
		UE_LOG(LogNiagaraCN, Log, TEXT("栈条目翻译: %d 个新翻译, %d 个视图模型已刷新"), TranslatedCount, VmCount);
		return true;
	}
	return false;
}

void FNiagaraCNModule::RestoreAllStackEntries()
{
	// Build set of Chinese values for quick lookup
	TSet<FString> ZhValues;
	for (const auto& P : EnToZh)
	{
		ZhValues.Add(P.Value);
	}

	int32 RestoredCount = 0;
	for (TObjectIterator<UObject> It; It; ++It)
	{
		UObject* Obj = *It;
		if (!Obj || !IsA(Obj, TEXT("NiagaraStackEntry"))) continue;

		UNiagaraStackEntry* Entry = static_cast<UNiagaraStackEntry*>(Obj);
		if (Entry->IsFinalized()) continue;

		// Clear AlternateDisplayName (set via editor data TMap)
		TOptional<FText> AltName = Entry->GetAlternateDisplayName();
		if (AltName.IsSet() && ZhValues.Contains(AltName.GetValue().ToString()))
		{
			UNiagaraStackEditorData& EditorData = Entry->GetStackEditorData();
			SetDisplayNameViaReflection(EditorData, Entry->GetStackEditorDataKey(), FText::GetEmpty());
			RestoredCount++;
		}

		// Clear SummaryViewDisplayNameOverride on function inputs
		if (IsA(Obj, TEXT("NiagaraStackFunctionInput")))
		{
			UNiagaraStackFunctionInput* Input = static_cast<UNiagaraStackFunctionInput*>(Obj);
			FString DisplayStr = Input->GetDisplayName().ToString();
			if (!DisplayStr.IsEmpty())
			{
				// Check if current display name looks translated (contains Chinese)
				bool bLooksTranslated = false;
				for (const TCHAR* s = *DisplayStr; *s; ++s)
				{
					if (*s >= 0x4E00 && *s <= 0x9FFF) { bLooksTranslated = true; break; }
				}
				if (bLooksTranslated)
				{
					Input->SetSummaryViewDisplayName(TAttribute<FText>());
					RestoredCount++;
				}
			}
		}
	}

	if (RestoredCount > 0)
	{
		// Trigger refresh on all stack view models
		for (TObjectIterator<UObject> It; It; ++It)
		{
			UObject* Obj = *It;
			if (!Obj || !IsA(Obj, TEXT("NiagaraStackViewModel"))) continue;

			UNiagaraStackViewModel* VM = static_cast<UNiagaraStackViewModel*>(Obj);
			if (VM->GetRootEntry() && !VM->GetRootEntry()->IsFinalized())
			{
				VM->RequestRefreshDeferred();
			}
		}
	}

	UE_LOG(LogNiagaraCN, Log, TEXT("栈条目还原: %d 个已清除"), RestoredCount);
}

void FNiagaraCNModule::StartStackEntryScan()
{
	if (GStackEntryScanHandle.IsValid())
	{
		FTSTicker::GetCoreTicker().RemoveTicker(GStackEntryScanHandle);
		GStackEntryScanHandle.Reset();
	}

	// Immediate first scan
	TranslateAllStackEntries();

	// Periodic scan every 2s. Only refreshes when new translations are found,
	// so no flashing after the initial setup.
	GStackEntryScanHandle = FTSTicker::GetCoreTicker().AddTicker(
		FTickerDelegate::CreateLambda([this](float) -> bool
		{
			if (!bEnabled)
			{
				GStackEntryScanHandle.Reset();
				return false;
			}
			// Skip expensive UObject iteration if no Niagara editor is open
			bool bHasViewModels = false;
			for (TObjectIterator<UObject> It; It; ++It)
			{
				UObject* Obj = *It;
				if (Obj && IsA(Obj, TEXT("NiagaraStackViewModel")))
				{
					UNiagaraStackViewModel* VM = static_cast<UNiagaraStackViewModel*>(Obj);
					if (VM->GetRootEntry() && !VM->GetRootEntry()->IsFinalized())
					{
						bHasViewModels = true;
						break;
					}
				}
			}
			if (bHasViewModels)
			{
				TranslateAllStackEntries();
			}
			return true;
		}),
		2.0f
	);
}

// ============================================================
//  Toolbar — Level Editor + Niagara Script Editor + Niagara System Editor
// ============================================================
static void FillNiagaraCNToolbar(FToolBarBuilder& Builder)
{
	Builder.AddToolBarButton(
		FUIAction(
			FExecuteAction::CreateLambda([](){ FNiagaraCNModule::SetEnabled(!FNiagaraCNModule::IsEnabled()); }),
			FCanExecuteAction(),
			FIsActionChecked::CreateLambda([](){ return FNiagaraCNModule::IsEnabled(); })
		),
		NAME_None,
		LOCTEXT("ToggleLabel", "中/英"),
		LOCTEXT("ToggleTip", "切换 Niagara 编辑器中文/英文显示"),
		FSlateIcon(FAppStyle::GetAppStyleSetName(), "ClassIcon.ParticleSystem"),
		EUserInterfaceActionType::ToggleButton
	);
}

void FNiagaraCNModule::RegisterToolbarToggle()
{
	// 1) Level Editor toolbar
	UToolMenu* LevelMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar.User");
	FToolMenuSection& LevelSection = LevelMenu->FindOrAddSection("NiagaraCNToggle");
	LevelSection.AddEntry(FToolMenuEntry::InitToolBarButton(
		TEXT("NiagaraCNToggle"),
		FUIAction(
			FExecuteAction::CreateLambda([](){ SetEnabled(!bEnabled); }),
			FCanExecuteAction(),
			FIsActionChecked::CreateLambda([](){ return bEnabled; })
		),
		LOCTEXT("ToggleLabel", "中/英"),
		LOCTEXT("ToggleTip", "切换 Niagara 编辑器中文/英文显示"),
		FSlateIcon(FAppStyle::GetAppStyleSetName(), "ClassIcon.ParticleSystem"),
		EUserInterfaceActionType::ToggleButton
	));

	// 2) Niagara Script Editor toolbar
	UToolMenu* ScriptToolbar = UToolMenus::Get()->ExtendMenu("AssetEditor.NiagaraScriptEditor.ToolBar");
	if (ScriptToolbar)
	{
		FToolMenuSection& ScriptSection = ScriptToolbar->FindOrAddSection("NiagaraCN");
		ScriptSection.AddEntry(FToolMenuEntry::InitToolBarButton(
			TEXT("NiagaraCNToggle_Script"),
			FUIAction(
				FExecuteAction::CreateLambda([](){ SetEnabled(!bEnabled); }),
				FCanExecuteAction(),
				FIsActionChecked::CreateLambda([](){ return bEnabled; })
			),
			LOCTEXT("ToggleLabel", "中/英"),
			LOCTEXT("ToggleTip", "切换中/英文显示"),
			FSlateIcon(FAppStyle::GetAppStyleSetName(), "ClassIcon.ParticleSystem"),
			EUserInterfaceActionType::ToggleButton
		));
	}

	// 3) Niagara System/Emitter Editor toolbar
	FNiagaraEditorModule* NiagaraModule = FModuleManager::GetModulePtr<FNiagaraEditorModule>("NiagaraEditor");
	if (NiagaraModule)
	{
		NiagaraToolbarExtender = MakeShareable(new FExtender);
		NiagaraToolbarExtender->AddToolBarExtension(
			"Asset",
			EExtensionHook::After,
			nullptr,
			FToolBarExtensionDelegate::CreateStatic(&FillNiagaraCNToolbar)
		);
		NiagaraModule->GetToolBarExtensibilityManager()->AddExtender(NiagaraToolbarExtender);
	}
}

#undef LOCTEXT_NAMESPACE
