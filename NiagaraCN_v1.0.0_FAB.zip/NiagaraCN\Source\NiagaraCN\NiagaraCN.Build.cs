using UnrealBuildTool;

public class NiagaraCN : ModuleRules
{
    public NiagaraCN(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(new string[]
        {
            "Core",
            "CoreUObject",
            "Engine",
        });

        PrivateDependencyModuleNames.AddRange(new string[]
        {
            "Slate",
            "SlateCore",
            "UnrealEd",
            "Niagara",
            "NiagaraEditor",
            "ToolMenus",
        });
    }
}
