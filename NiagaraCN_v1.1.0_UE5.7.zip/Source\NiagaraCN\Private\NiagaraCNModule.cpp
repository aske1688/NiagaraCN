// Copyright aske1688 2025-2026. All rights reserved.

#include "NiagaraCNModule.h"
#include "Internationalization/TextLocalizationManager.h"
#include "ToolMenus.h"
#include "Styling/AppStyle.h"
#include "NiagaraEditorModule.h"
#include "NiagaraStackEditorData.h"
#include "ViewModels/Stack/NiagaraStackViewModel.h"
#include "ViewModels/Stack/NiagaraStackEntry.h"
#include "ViewModels/Stack/NiagaraStackFunctionInput.h"
#include "UObject/UnrealType.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/SWindow.h"
#include "Rendering/SlateRenderer.h"
#include "SNiagaraGraphActionWidget.h"
#include "NiagaraActions.h"

DEFINE_LOG_CATEGORY_STATIC(LogNiagaraCN, Log, All);
#define LOCTEXT_NAMESPACE "FNiagaraCNModule"

IMPLEMENT_MODULE(FNiagaraCNModule, NiagaraCN)

static FTSTicker::FDelegateHandle GStackEntryScanHandle;
static FTSTicker::FDelegateHandle GAddModuleSearchHandle;

static bool AddModuleSearchTick(float DeltaTime);
static void OnSlateWindowRendered(SWindow& Window, void*);
static TSet<void*> GTranslatedActions; // avoid re-translating same action

bool FNiagaraCNModule::bEnabled = true;

// ============================================================
//  Custom ILocalizedTextSource — intercepts at FText level
//  Provides Chinese translations as "en" localized data.
// ============================================================
class FNiagaraCNTextSource : public ILocalizedTextSource
{
public:
	explicit FNiagaraCNTextSource(const TMap<FString,FString>& InDict)
		: Dict(InDict)
	{}

	virtual int32 GetPriority() const override
	{
		return ELocalizedTextSourcePriority::Lowest;
	}

	virtual bool GetNativeCultureName(const ELocalizedTextSourceCategory InCategory, FString& OutNativeCultureName) override
	{
		OutNativeCultureName = TEXT("en");
		return true;
	}

	virtual void GetLocalizedCultureNames(const ELocalizationLoadFlags InLoadFlags, TSet<FString>& OutLocalizedCultureNames) override
	{
		OutLocalizedCultureNames.Add(TEXT("en"));
	}

	virtual void LoadLocalizedResources(const ELocalizationLoadFlags InLoadFlags, TArrayView<const FString> InPrioritizedCultures, FTextLocalizationResource& InOutNativeResource, FTextLocalizationResource& InOutLocalizedResource) override
	{
		if (!bModuleEnabled) return;
		if (InOutNativeResource.Entries.Num() == 0) return;

		int32 MatchCount = 0;
		for (const auto& Pair : InOutNativeResource.Entries)
		{
			const FString KeyStr = Pair.Key.GetKey().ToString();
			const FString* Zh = Dict.Find(KeyStr);
			if (!Zh && Pair.Value.LocalizedString.IsValid())
			{
				Zh = Dict.Find(*Pair.Value.LocalizedString);
			}
			if (Zh)
			{
				InOutLocalizedResource.AddEntry(
					Pair.Key.GetNamespace(),
					Pair.Key.GetKey(),
					Pair.Value.SourceStringHash,
					*Zh,
					0
				);
				MatchCount++;
			}
		}
		UE_LOG(LogNiagaraCN, Log, TEXT("FText管道: NativeEntries=%d, Matched=%d"),
			InOutNativeResource.Entries.Num(), MatchCount);
	}

	static void SetEnabled(bool bEnable) { bModuleEnabled = bEnable; }

private:
	TMap<FString,FString> Dict;
	static bool bModuleEnabled;
};

bool FNiagaraCNTextSource::bModuleEnabled = true;

// ============================================================
//  Dictionary
// ============================================================
static const TCHAR* RawPairs[] = {
	TEXT("Calculate Mass and Rotational Inertia by Volume"), TEXT("按体积计算质量和旋转惯性"),
	TEXT("Calculate Size and Rotational Inertia by Volume"), TEXT("按体积计算尺度和旋转惯性"),
	TEXT("Update MS Vertex Animation Tools Morph Targets"), TEXT("更新 MS 顶点动画工具变形目标"),
	TEXT("Spawn MS Vertex Animation Tools Morph Target"), TEXT("生成 MS 顶点动画工具变换目标"),
	TEXT("Calculate Mass and Rotational Inertia by Mass"), TEXT("按质量计算质量和旋转惯性"),
	TEXT("Maintain a Set Distance Between Two Points"), TEXT("两点之间维持设定距离"),
	TEXT("Update Velocity on Mass Change"), TEXT("质量变化时更新速度"),
	TEXT("Add Rotational Velocity"), TEXT("添加旋转速度"),
	TEXT("Generate Grid Ribbon IDs"), TEXT("生成网格条带 ID"),
	TEXT("Time Based State Machine"), TEXT("基于时间状态机"),
	TEXT("Find Kinetic and Potential Energy"), TEXT("查找动能和势能"),
	TEXT("Align Particles with Collision Plane"), TEXT("粒子与碰撞平面对齐"),
	TEXT("Kill Particles in Volume"), TEXT("去除体积中的粒子"),
	TEXT("Maintain in Camera Particle Scale"), TEXT("保持摄像机粒子比例"),
	TEXT("Sample Pseudo Volume Texture"), TEXT("取样伪体积纹理"),
	TEXT("Sample Skeletal Mesh Surface"), TEXT("采样骨架网格体表面"),
	TEXT("Sample Skeletal Mesh Skeleton"), TEXT("采样骨架网格体骨架"),
	TEXT("Skeletal Mesh Skeleton Location"), TEXT("骨架网格体骨架位置"),
	TEXT("Generate Location Events"), TEXT("生成位置事件"),
	TEXT("Generate Collision Event"), TEXT("生成碰撞事件"),
	TEXT("Generate Death Event"), TEXT("生成死亡事件"),
	TEXT("Skeletal Mesh Location"), TEXT("骨架网格体位置"),
	TEXT("Static Mesh Location"), TEXT("静态网格体位置"),
	TEXT("World Aligned Texture Sample"), TEXT("场景对齐纹理取样"),
	TEXT("Sub UV Texture Sample"), TEXT("子 UV 纹理取样"),
	TEXT("Calculate Accurate Velocity"), TEXT("计算准确速度"),
	TEXT("Preview Scene Settings"), TEXT("预览场景设置"),
	TEXT("Emitter Frame Counter"), TEXT("发射器帧计数器"),
	TEXT("Attribute Spreadsheet"), TEXT("属性表"),
	TEXT("Dynamic Material Parameters"), TEXT("动态材质参数"),
	TEXT("Simulation Stage"), TEXT("模拟阶段"),
	TEXT("Static Switch"), TEXT("静态开关"),
	TEXT("Stack Context"), TEXT("栈上下文"),
	TEXT("Niagara Message Log"), TEXT("Niagara 消息日志"),
	TEXT("Niagara Editor"), TEXT("Niagara 编辑器"),
	TEXT("Niagara System"), TEXT("Niagara 系统"),
	TEXT("Niagara Emitter"), TEXT("Niagara 发射器"),
	TEXT("Niagara Log"), TEXT("Niagara 日志"),
	TEXT("Generated Code"), TEXT("生成代码"),
	TEXT("Legacy Parameters"), TEXT("旧版参数"),
	TEXT("Parameter Map"), TEXT("参数映射"),
	TEXT("Execution State"), TEXT("执行状态"),
	TEXT("Inactive Response"), TEXT("非活跃响应"),

	// Renderers
	TEXT("Component Renderer"), TEXT("组件渲染器"),
	TEXT("Light Renderer"), TEXT("光源渲染器"),
	TEXT("Mesh Renderer"), TEXT("网格体渲染器"),
	TEXT("Ribbon Renderer"), TEXT("条带渲染器"),
	TEXT("Sprite Renderer"), TEXT("Sprite 渲染器"),
	TEXT("Decal Renderer"), TEXT("贴花渲染器"),
	TEXT("Render Visibility Tag"), TEXT("渲染可见性标签"),
	TEXT("Material Parameter Bind"), TEXT("材质参数绑定"),
	TEXT("UV Scale & Offset"), TEXT("UV 缩放与偏移"),
	TEXT("Camera Offset"), TEXT("摄像机偏移"),
	TEXT("SubUV Animation"), TEXT("子 UV 动画"),
	TEXT("Sprite Rotation Rate"), TEXT("Sprite 旋转率"),
	TEXT("Dynamic Parameter"), TEXT("动态参数"),
	TEXT("Facing Mode"), TEXT("朝向模式"),
	TEXT("Sort Mode"), TEXT("排序模式"),
	TEXT("Blend Mode"), TEXT("混合模式"),
	TEXT("Pivot Offset"), TEXT("锚点偏移"),
	TEXT("Sub UV"), TEXT("子 UV"),

	// Stack Groups
	TEXT("Particle Spawn Group"), TEXT("粒子生成组"),
	TEXT("Particle Update Group"), TEXT("粒子更新组"),
	TEXT("Emitter Spawn Group"), TEXT("发射器生成组"),
	TEXT("Emitter Update Group"), TEXT("发射器更新组"),
	TEXT("System Spawn Group"), TEXT("系统生成组"),
	TEXT("System Update Group"), TEXT("系统更新组"),
	TEXT("Render Group"), TEXT("渲染组"),
	TEXT("Event Handler"), TEXT("事件处理器"),

	// Spawn modules
	TEXT("Spawn Burst Instantaneous"), TEXT("生成即时迸发"),
	TEXT("Spawn Particles in Grid"), TEXT("在网格中生成粒子"),
	TEXT("Spawn from Chaos"), TEXT("从 Chaos 中生成"),
	TEXT("Event Driven Spawn"), TEXT("事件驱动生成"),
	TEXT("Determine Spawn Count"), TEXT("确定生成数量"),
	TEXT("Spawn Per Unit"), TEXT("每单位生成"),
	TEXT("Spawn Per Frame"), TEXT("每帧生成"),
	TEXT("Spawn Rate"), TEXT("生成速率"),
	TEXT("Spawn Burst"), TEXT("爆发生成"),
	TEXT("Spawn Beam"), TEXT("生成光束"),
	TEXT("Spawn Info"), TEXT("生成信息"),

	// Initialize
	TEXT("Initialize Mesh Reproduction Sprite"), TEXT("初始化网格体复制 Sprite"),
	TEXT("Update Mesh Reproduction Sprite"), TEXT("更新网格体复制 Sprite"),
	TEXT("Initialize Particle"), TEXT("初始化粒子"),
	TEXT("Initialize Ribbon"), TEXT("初始化条带"),
	TEXT("Beam Emitter Setup"), TEXT("光束发射器设置"),

	// Location
	TEXT("Rotate Around Point"), TEXT("绕点旋转"),
	TEXT("Box Location"), TEXT("盒体位置"),
	TEXT("Cone Location"), TEXT("锥体位置"),
	TEXT("Cylinder Location"), TEXT("圆柱体位置"),
	TEXT("Grid Location"), TEXT("网格位置"),
	TEXT("Jitter Position"), TEXT("抖动位置"),
	TEXT("Sphere Location"), TEXT("球体位置"),
	TEXT("System Location"), TEXT("系统位置"),
	TEXT("Torus Location"), TEXT("圆环位置"),
	TEXT("Mesh Location"), TEXT("网格体位置"),

	// Location (missing)
	TEXT("Shape Location"), TEXT("形状位置"),
	TEXT("Curl Noise Location"), TEXT("旋度噪声位置"),
	TEXT("Wedge Location"), TEXT("楔形位置"),
	TEXT("Socket Location"), TEXT("插槽位置"),
	TEXT("Skeletal Mesh Surface Location"), TEXT("骨骼网格体表面位置"),
	TEXT("Sample Bezier Spline Location and Tangent"), TEXT("采样贝塞尔样条位置与切线"),
	TEXT("Place Particles on a Rectangle"), TEXT("在矩形上放置粒子"),
	TEXT("Place Particles on Depth Buffer GPU"), TEXT("在深度缓冲上放置粒子 GPU"),

	// Velocity
	TEXT("Add Velocity from Point"), TEXT("添加点中速度"),
	TEXT("Add Velocity in Cone"), TEXT("在锥体中添加速度"),
	TEXT("Align Velocity to Random Axis"), TEXT("将速度对齐随机轴"),
	TEXT("Static Mesh Velocity"), TEXT("静态网格体速度"),
	TEXT("Solve Forces and Velocity"), TEXT("解算力与速度"),
	TEXT("Inherit Velocity"), TEXT("继承速度"),
	TEXT("Scale Velocity"), TEXT("缩放速度"),
	TEXT("Vortex Velocity"), TEXT("旋涡速度"),
	TEXT("Velocity Cone"), TEXT("锥形速度"),
	TEXT("Add Velocity"), TEXT("添加速度"),
	TEXT("Initial Rotational Velocity"), TEXT("初始旋转速度"),
	TEXT("Solve Rotational Forces and Velocity"), TEXT("解算旋转力与速度"),
	TEXT("Match Velocity Via Force"), TEXT("通过力匹配速度"),
	TEXT("Scale Velocity"), TEXT("缩放速度"), // already exists but ensure

	// Force
	TEXT("Line Attraction Force"), TEXT("线吸引力"),
	TEXT("Point Attraction Force"), TEXT("点引力"),
	TEXT("Mesh Rotation Force"), TEXT("网格体旋转力"),
	TEXT("Vector Noise Force"), TEXT("向量噪点力"),
	TEXT("Acceleration Force"), TEXT("加速力"),
	TEXT("Apply Initial Forces"), TEXT("施加初始力"),
	TEXT("Curl Noise Force"), TEXT("旋度噪点力"),
	TEXT("Gravity Force"), TEXT("重力"),
	TEXT("Rotational Force"), TEXT("旋转力"),
	TEXT("Point Attraction"), TEXT("点引力"),
	TEXT("Linear Force"), TEXT("线性力"),
	TEXT("Vortex Force"), TEXT("旋涡力"),
	TEXT("Radial Force"), TEXT("径向力"),
	TEXT("Spring Force"), TEXT("弹簧力"),
	TEXT("Wind Force"), TEXT("风力"),
	TEXT("Point Force"), TEXT("点力"),
	TEXT("Limit Force"), TEXT("限制力"),
	TEXT("Drag"), TEXT("阻力"),
	TEXT("Aerodynamic Drag"), TEXT("空气阻力"),
	TEXT("Drag Force"), TEXT("拖拽力"),
	TEXT("Inherit Source Movement"), TEXT("继承源运动"),

	// Constraint
	TEXT("Pendulum Constraint"), TEXT("钟摆约束"),
	TEXT("Pendulum Setup"), TEXT("钟摆设置"),
	TEXT("Calculate Link Constraint"), TEXT("计算链接约束"),
	TEXT("Solve Float Spring Constraint"), TEXT("解算浮点弹簧约束"),
	TEXT("Constrain Position to Plane"), TEXT("约束位置至平面"),
	TEXT("Constrain Vector to Cone"), TEXT("约束向量至锥体"),

	// Color
	TEXT("Scale Color by Speed"), TEXT("按速度缩放颜色"),
	TEXT("Scale Color by Velocity"), TEXT("按速度缩放颜色"),
	TEXT("Color"), TEXT("颜色"),
	TEXT("Particle Color Params"), TEXT("粒子颜色参数"),
	TEXT("Color by Speed"), TEXT("速度着色"),
	TEXT("Color Mode"), TEXT("颜色模式"),
	TEXT("Color Output"), TEXT("颜色输出"),
	TEXT("Scale Color"), TEXT("缩放颜色"),
	TEXT("Linear Color"), TEXT("线性颜色"),

	// Size
	TEXT("Scale Mesh Size by Speed"), TEXT("按速度缩放网格体尺寸"),
	TEXT("Scale Sprite Size by Velocity"), TEXT("按速度缩放 Sprite 尺寸"),
	TEXT("Sprite Size Scale"), TEXT("Sprite 尺寸缩放"),
	TEXT("Sprite Size Scale by Speed"), TEXT("按速度缩放 Sprite 尺寸"),
	TEXT("Sprite Size Scale by Velocity"), TEXT("按速度缩放 Sprite 尺寸"),
	TEXT("Mesh Size Scale"), TEXT("网格体尺寸缩放"),
	TEXT("Scale Attributes by Camera Distance"), TEXT("按摄像机距离缩放属性"),
	TEXT("Apply Owner Scale to Attributes"), TEXT("应用所有者缩放至属性"),
	TEXT("Calculate Size by Mass"), TEXT("按质量计算大小"),
	TEXT("Calculate Mass by Volume"), TEXT("按体积计算质量"),
	TEXT("Calculate Size and Rotational Inertia by Mass"), TEXT("按质量计算大小和旋转惯性"),
	TEXT("Scale Sprite Size by Speed"), TEXT("按速度缩放 Sprite 尺寸"),
	TEXT("Scale Mesh Size"), TEXT("缩放网格体尺寸"),
	TEXT("Scale Sprite Size"), TEXT("缩放 Sprite 尺寸"),
	TEXT("Beam Width Scale"), TEXT("光束宽度缩放"),
	TEXT("Ribbon Width Scale"), TEXT("条带宽度"),
	TEXT("Size by Speed"), TEXT("速度大小"),
	TEXT("Beam Width"), TEXT("光束宽度"),

	// Orientation
	TEXT("Align Sprite to Mesh Orientation"), TEXT("将 Sprite 与网格体朝向对齐"),
	TEXT("Initial Mesh Orientation"), TEXT("初始网格体朝向"),
	TEXT("Orient Mesh to Vector"), TEXT("将网格体朝向向量"),
	TEXT("Update Mesh Orientation"), TEXT("更新网格体朝向"),
	TEXT("Orient Mesh to Camera"), TEXT("网格体朝向摄像机"),
	TEXT("Initial Mesh Rotation"), TEXT("初始网格体旋转"),
	TEXT("Initial Mesh Rotation Rate"), TEXT("初始网格体旋转率"),
	TEXT("Mesh Rotation Rate"), TEXT("网格体旋转率"),
	TEXT("Sprite Facing and Alignment"), TEXT("Sprite 面向与对齐"),
	TEXT("Initial Decal Orientation"), TEXT("初始贴花朝向"),
	TEXT("Update Decal Orientation"), TEXT("更新贴花朝向"),
	TEXT("Mesh Look At"), TEXT("网格体朝向"),
	TEXT("Flight Orientation"), TEXT("飞行朝向"),
	TEXT("Pure Roll Orientation"), TEXT("纯翻滚朝向"),

	// Collision
	TEXT("Collision Event"), TEXT("碰撞事件"),
	TEXT("Ray Collision"), TEXT("射线碰撞"),
	TEXT("Depth Collision"), TEXT("深度碰撞"),
	TEXT("Collision"), TEXT("碰撞"),
	TEXT("Collision Query"), TEXT("碰撞查询"),
	TEXT("Collision Query and Response"), TEXT("碰撞查询与响应"),
	TEXT("Collision Linear Impulse"), TEXT("碰撞线性冲量"),
	TEXT("Collision Rest"), TEXT("碰撞静止"),
	TEXT("Analytical Collision Query"), TEXT("解析碰撞查询"),
	TEXT("Niagara Distance Field Collisions"), TEXT("Niagara 距离场碰撞"),
	TEXT("PBD Intra Particle Collision"), TEXT("PBD 粒子间碰撞"),
	TEXT("Scene Depth Test"), TEXT("场景深度测试"),
	TEXT("Find Tangential Velocity on Sphere"), TEXT("查找球体切向速度"),
	TEXT("Calculate Line Plane Int"), TEXT("计算线面交点"),
	TEXT("Initialize Neighbor Grid"), TEXT("初始化邻居网格"),
	TEXT("Populate Neighbor Grid"), TEXT("填充邻居网格"),
	TEXT("Setup Rigid Body DI"), TEXT("设置刚体数据接口"),

	// Kill / Lifecycle
	TEXT("Kill Particles"), TEXT("去除粒子"),
	TEXT("Complete If Unused"), TEXT("未使用时完成"),
	TEXT("Emitter Life Cycle"), TEXT("发射器生命周期"),
	TEXT("System Life Cycle"), TEXT("系统生命周期"),
	TEXT("Do Once"), TEXT("仅执行一次"),

	// Events
	TEXT("Location Event"), TEXT("位置事件"),
	TEXT("Death Event"), TEXT("死亡事件"),
	TEXT("Generate Event"), TEXT("生成事件"),
	TEXT("Event Payload"), TEXT("事件载荷"),
	TEXT("Receive Collision Event"), TEXT("接收碰撞事件"),
	TEXT("Receive Death Event"), TEXT("接收死亡事件"),
	TEXT("Receive Location Event"), TEXT("接收位置事件"),
	TEXT("Debug Collision Events"), TEXT("调试碰撞事件"),

	// Mesh / Skeletal
	TEXT("Sample Skeletal Mesh"), TEXT("采样骨骼网格体"),
	TEXT("Sample Skeletal Mesh Skeleton"), TEXT("采样骨骼网格体骨架"),
	TEXT("Sample Static Mesh"), TEXT("采样静态网格体"),
	TEXT("Sample Static Mesh Position Only"), TEXT("采样静态网格体仅位置"),
	TEXT("Traverse Skeletal Mesh"), TEXT("遍历骨骼网格体"),
	TEXT("Initialize Traverse Skeletal Mesh"), TEXT("初始化遍历骨骼网格体"),
	TEXT("Prepare Traverse Skeletal Mesh"), TEXT("准备遍历骨骼网格体"),
	TEXT("Apply Traverse Skeletal Mesh Update"), TEXT("应用遍历骨骼网格体更新"),

	// Audio
	TEXT("Play Audio"), TEXT("播放音频"),
	TEXT("Play Looping Audio"), TEXT("播放循环音频"),
	TEXT("Play Persistent Audio"), TEXT("播放持久音频"),
	TEXT("Initialize Audio Player"), TEXT("初始化音频播放器"),
	TEXT("Set Initial Audio Parameter"), TEXT("设置初始音频参数"),
	TEXT("Update Persistent Audio"), TEXT("更新持久音频"),

	// Math
	TEXT("Lerp Particle Attributes"), TEXT("插值粒子属性"),
	TEXT("Recreate Camera Projection"), TEXT("重新创建摄像机投射"),
	TEXT("Temporal Lerp Float"), TEXT("时间插值浮点"),
	TEXT("Temporal Lerp Vector"), TEXT("时间插值向量"),
	TEXT("Cross Product"), TEXT("叉积"),
	TEXT("Dot Product"), TEXT("点积"),
	TEXT("Smooth Step"), TEXT("平滑阶跃"),
	TEXT("Remap Range"), TEXT("范围重映射"),
	TEXT("Color Curves"), TEXT("颜色曲线"),
	TEXT("Size Curves"), TEXT("大小曲线"),
	TEXT("Curve Editor"), TEXT("曲线编辑器"),
	TEXT("Cone Mask"), TEXT("锥体遮罩"),
	TEXT("Normalize"), TEXT("归一化"),
	TEXT("Saturate"), TEXT("饱和钳制"),
	TEXT("Distance"), TEXT("距离"),
	TEXT("Length"), TEXT("长度"),
	TEXT("Floor"), TEXT("向下取整"),
	TEXT("Cosine"), TEXT("余弦"),
	TEXT("Sine"), TEXT("正弦"),
	TEXT("Ceil"), TEXT("向上取整"),
	TEXT("Frac"), TEXT("小数部分"),
	TEXT("Lerp"), TEXT("线性插值"),
	TEXT("Clamp"), TEXT("钳制"),
	TEXT("Slerp Vector"), TEXT("球面线性插值向量"),
	TEXT("Avoid Cone"), TEXT("避让锥体"),
	TEXT("Constrain Vector to Cone"), TEXT("约束向量至锥体"),
	TEXT("Cone Sphere Intersection"), TEXT("锥球相交"),
	TEXT("Sphere Plane Intersection"), TEXT("球面相交"),
	TEXT("Find Closest Point on Line Segment"), TEXT("查找线段最近点"),
	TEXT("Find Closest Point on Triangle"), TEXT("查找三角形最近点"),
	TEXT("Find Screen Space Bounding Box"), TEXT("查找屏幕空间包围盒"),
	TEXT("Min Max Op With Valid Checks"), TEXT("带验证的最小最大值运算"),
	TEXT("Track Distance Traveled"), TEXT("追踪行进距离"),
	TEXT("Interpolate Over Time"), TEXT("随时间插值"),
	TEXT("Fade Over Time"), TEXT("随时间淡出"),
	TEXT("Sample Bezier Spline"), TEXT("采样贝塞尔样条"),
	TEXT("Read Distance Field GPU"), TEXT("读取距离场 GPU"),
	TEXT("Ray Trace"), TEXT("光线追踪"),
	TEXT("Ray Trace Distance Field GPU"), TEXT("光线追踪距离场 GPU"),
	TEXT("Async GPU Trace"), TEXT("异步 GPU 追踪"),
	TEXT("Avoid Distance Field Surfaces GPU"), TEXT("避让距离场表面 GPU"),
	TEXT("Move to Nearest Distance Field Surface GPU"), TEXT("移至最近距离场表面 GPU"),
	TEXT("Query GBuffer"), TEXT("查询 GBuffer"),
	TEXT("Region Mask"), TEXT("区域遮罩"),
	TEXT("Apply Rotation Vector"), TEXT("应用旋转向量"),

	// Texture
	TEXT("Sample Texture"), TEXT("取样纹理"),
	TEXT("Texture Data"), TEXT("纹理数据"),

	// Vector Field
	TEXT("Apply Vector Field"), TEXT("应用向量场"),
	TEXT("Sample Vector Field"), TEXT("取样向量场"),
	TEXT("Vector Field"), TEXT("向量场"),

	// Chaos / Audio
	TEXT("Apply Chaos Data"), TEXT("应用混沌数据"),
	TEXT("Audio Data"), TEXT("音频数据"),

	// State / Lifetime
	TEXT("Increment Over Time"), TEXT("随时间增量"),
	TEXT("Particle State"), TEXT("粒子状态"),
	TEXT("Emitter State"), TEXT("发射器状态"),
	TEXT("System State"), TEXT("系统状态"),
	TEXT("Update Age"), TEXT("更新年龄"),
	TEXT("Lifetime"), TEXT("生命周期"),

	// Scalability
	TEXT("Emitter Scalability"), TEXT("发射器可扩展性"),
	TEXT("System Scalability"), TEXT("系统可扩展性"),
	TEXT("Num Instances Cull"), TEXT("实例数剔除"),

	// System / Emitter core
	TEXT("System Overview"), TEXT("系统概览"),
	TEXT("Emitter Summary"), TEXT("发射器摘要"),
	TEXT("Selected Emitter"), TEXT("当前发射器"),
	TEXT("Selected Details"), TEXT("选定细节"),
	TEXT("System Details"), TEXT("系统细节"),
	TEXT("Script Details"), TEXT("脚本细节"),
	TEXT("Script Stats"), TEXT("脚本统计数据"),
	TEXT("Scratch Pad"), TEXT("暂存区"),
	TEXT("Node Graph"), TEXT("节点图表"),
	TEXT("Particle Spawn"), TEXT("粒子生成"),
	TEXT("Particle Death"), TEXT("粒子消亡"),
	TEXT("Particle Update"), TEXT("粒子更新"),
	TEXT("Emitter Spawn"), TEXT("发射器生成"),
	TEXT("Emitter Update"), TEXT("发射器更新"),
	TEXT("System Spawn"), TEXT("系统生成"),
	TEXT("System Update"), TEXT("系统更新"),

	// Execution States
	TEXT("InactiveClear"), TEXT("非活跃清除"),
	TEXT("Inactive"), TEXT("非活跃"),
	TEXT("Active"), TEXT("活跃"),
	TEXT("Complete"), TEXT("完成"),

	// Namespaces
	TEXT("Namespace"), TEXT("命名空间"),
	TEXT("Transient"), TEXT("瞬态"),
	TEXT("Particles"), TEXT("粒子"),
	TEXT("Emitter"), TEXT("发射器"),
	TEXT("System"), TEXT("系统"),
	TEXT("Engine"), TEXT("引擎"),
	TEXT("User"), TEXT("用户"),

	// Data Types
	TEXT("Niagara ID"), TEXT("Niagara 标识"),
	TEXT("Half Vector"), TEXT("半精度向量"),
	TEXT("Quaternion"), TEXT("四元数"),
	TEXT("Vector 2D"), TEXT("二维向量"),
	TEXT("Vector 4"), TEXT("四维向量"),
	TEXT("Position"), TEXT("位置"),
	TEXT("Vector"), TEXT("三维向量"),
	TEXT("Half"), TEXT("半精度浮点"),
	TEXT("float"), TEXT("浮点数"),
	TEXT("int32"), TEXT("整数"),
	TEXT("bool"), TEXT("布尔"),

	// Data Interfaces
	TEXT("Skeletal Mesh Data"), TEXT("骨骼网格体数据"),
	TEXT("Static Mesh Data"), TEXT("静态网格体数据"),
	TEXT("Neighbor Grid 3D"), TEXT("邻居网格 3D"),
	TEXT("Curl Noise Data"), TEXT("旋度噪声数据"),
	TEXT("Occlusion Query"), TEXT("遮挡查询"),
	TEXT("GBuffer Data"), TEXT("GBuffer 数据"),
	TEXT("Spline Data"), TEXT("样条线数据"),
	TEXT("Data Interfaces"), TEXT("数据接口"),
	TEXT("Data Interface"), TEXT("数据接口"),
	TEXT("Grid 3D"), TEXT("三维网格"),
	TEXT("Grid 2D"), TEXT("二维网格"),

	// GPU / Simulation
	TEXT("GPU Data Interface"), TEXT("GPU 数据接口"),
	TEXT("GPU Simulation"), TEXT("GPU 模拟"),
	TEXT("CPU Simulation"), TEXT("CPU 模拟"),
	TEXT("Custom HLSL"), TEXT("自定义 HLSL"),
	TEXT("Iteration Count"), TEXT("迭代次数"),

	// Performance / Bounds
	TEXT("Fixed Bounds"), TEXT("固定包围盒"),
	TEXT("Particle Count"), TEXT("粒子计数"),
	TEXT("Max Particles"), TEXT("最大粒子数"),
	TEXT("LOD Distance"), TEXT("LOD 距离"),
	TEXT("Scalability"), TEXT("可扩展性"),
	TEXT("Significance"), TEXT("重要性"),
	TEXT("Bounds"), TEXT("包围盒"),

	// Noise / Random
	TEXT("Voronoi Noise"), TEXT("Voronoi 噪声"),
	TEXT("Perlin Noise"), TEXT("柏林噪声"),
	TEXT("Curl Noise"), TEXT("旋度噪声"),
	TEXT("Random Range"), TEXT("随机范围"),
	TEXT("Random Float"), TEXT("随机浮点"),
	TEXT("Random Vector"), TEXT("随机向量"),
	TEXT("Noise"), TEXT("噪声"),
	TEXT("Seed"), TEXT("随机种子"),

	// Debug / Export / Utility
	TEXT("Debug Draw"), TEXT("调试绘制"),
	TEXT("Sprite Based Line"), TEXT("基于 Sprite 的线条"),
	TEXT("Export Particle Data to Blueprint"), TEXT("导出粒子数据至蓝图"),
	TEXT("Cascade Conversion Initial Mesh Rotation"), TEXT("Cascade 转换初始网格体旋转"),
	TEXT("Cascade Conversion Light Properties"), TEXT("Cascade 转换光源属性"),
	TEXT("Cascade Conversion Orbit"), TEXT("Cascade 转换轨道"),
	TEXT("Cascade Conversion Solve Orbit"), TEXT("Cascade 转换解算轨道"),
	TEXT("Generate Grid Ribbon IDs"), TEXT("生成网格条带 ID"),
	TEXT("Generate Mesh Torque"), TEXT("生成网格体扭矩"),
	TEXT("Generate Torque"), TEXT("生成扭矩"),
	TEXT("Partition Particles"), TEXT("分区粒子"),
	TEXT("Frame Counter"), TEXT("帧计数器"),
	TEXT("Set Alternate Renderer Bindings"), TEXT("设置备用渲染器绑定"),
	TEXT("View Recycler"), TEXT("视图回收器"),
	TEXT("Sample Particles from Other Emitter"), TEXT("从其他发射器采样粒子"),
	TEXT("Spawn Particles from Other Emitter"), TEXT("从其他发射器生成粒子"),
	TEXT("Update Particles from Other Emitter"), TEXT("从其他发射器更新粒子"),
	TEXT("World Aligned Texture Sample"), TEXT("世界对齐纹理采样"),

	// Common modules / actions
	TEXT("Add Velocity in Cone"), TEXT("锥形添加速度"),
	TEXT("Add Module"), TEXT("添加模块"),
	TEXT("Remove Module"), TEXT("移除模块"),
	TEXT("Enable Module"), TEXT("启用模块"),
	TEXT("Debug Draw"), TEXT("调试绘制"),
	TEXT("Set Variable"), TEXT("设置变量"),
	TEXT("Map Get"), TEXT("映射获取"),
	TEXT("Map Set"), TEXT("映射设置"),
	TEXT("Expression"), TEXT("表达式"),
	TEXT("Interpolation"), TEXT("插值生成"),
	TEXT("Module"), TEXT("模块"),
	TEXT("Function"), TEXT("函数"),
	TEXT("Input"), TEXT("输入"),
	TEXT("Output"), TEXT("输出"),

	// Parameters: Particles.xxx
	TEXT("Particles.NormalizedAge"), TEXT("粒子.归一化年龄"),
	TEXT("Particles.SpriteSize"), TEXT("粒子.Sprite 大小"),
	TEXT("Particles.Lifetime"), TEXT("粒子.生命周期"),
	TEXT("Particles.Velocity"), TEXT("粒子.速度"),
	TEXT("Particles.Position"), TEXT("粒子.位置"),
	TEXT("Particles.Scale"), TEXT("粒子.缩放"),
	TEXT("Particles.Mass"), TEXT("粒子.质量"),
	TEXT("Particles.Color"), TEXT("粒子.颜色"),
	TEXT("Particles.Age"), TEXT("粒子.年龄"),
	TEXT("Particles.ID"), TEXT("粒子.ID"),

	// Parameters: Emitter.xxx
	TEXT("Emitter.NumParticles"), TEXT("发射器.粒子数"),
	TEXT("Emitter.LoopedAge"), TEXT("发射器.循环年龄"),
	TEXT("Emitter.Age"), TEXT("发射器.运行时间"),

	// Parameters: Engine.xxx
	TEXT("Engine.Owner.Rotation"), TEXT("引擎.拥有者.旋转"),
	TEXT("Engine.Owner.Position"), TEXT("引擎.拥有者.位置"),
	TEXT("Engine.DeltaTime"), TEXT("引擎.帧间隔"),
	TEXT("Engine.Time"), TEXT("引擎.时间"),

	// Parameters: System.xxx
	TEXT("System.ExecutionState"), TEXT("系统.执行状态"),
	TEXT("System.NumEmitters"), TEXT("系统.发射器数量"),
	TEXT("System.Age"), TEXT("系统.运行时间"),

	// Editor UI panels
	TEXT("Engine Provided"), TEXT("引擎提供"),
	TEXT("Modules Locals"), TEXT("模块本地值"),
	TEXT("Module Inputs"), TEXT("模块输入"),
	TEXT("Particle Attributes"), TEXT("粒子属性"),
	TEXT("Emitter Attributes"), TEXT("发射器属性"),
	TEXT("System Attributes"), TEXT("系统属性"),
	TEXT("Preview"), TEXT("预览"),
	TEXT("Timeline"), TEXT("时间轴"),
	TEXT("Toolbar"), TEXT("工具栏"),
	TEXT("Viewport"), TEXT("视口"),
	TEXT("Parameters"), TEXT("参数"),
	TEXT("Properties"), TEXT("属性"),
	TEXT("Attributes"), TEXT("属性"),
	TEXT("Settings"), TEXT("设置"),
	TEXT("Details"), TEXT("细节"),
	TEXT("General"), TEXT("常规"),
	TEXT("Advanced"), TEXT("高级"),
	TEXT("Selection"), TEXT("选择"),
	TEXT("Alignment"), TEXT("对齐方式"),
	TEXT("Curves"), TEXT("曲线"),
	TEXT("Stats"), TEXT("统计数据"),
	TEXT("Script"), TEXT("脚本"),
	TEXT("Material"), TEXT("材质"),

	// Property names
	TEXT("Distribution"), TEXT("分布"),
	TEXT("Hue"), TEXT("色调"),
	TEXT("Saturation"), TEXT("饱和度"),
	TEXT("Value"), TEXT("明度"),
	TEXT("Alpha"), TEXT("透明度"),
	TEXT("Brightness"), TEXT("亮度"),
	TEXT("Contrast"), TEXT("对比度"),
	TEXT("Intensity"), TEXT("强度"),
	TEXT("Opacity"), TEXT("不透明度"),
	TEXT("Tint"), TEXT("色调"),
	TEXT("Override"), TEXT("覆盖"),
	TEXT("Inherit"), TEXT("继承"),
	TEXT("Radius"), TEXT("半径"),
	TEXT("Height"), TEXT("高度"),
	TEXT("Width"), TEXT("宽度"),
	TEXT("Thickness"), TEXT("厚度"),
	TEXT("Angle"), TEXT("角度"),
	TEXT("Pitch"), TEXT("俯仰角"),
	TEXT("Yaw"), TEXT("偏航角"),
	TEXT("Roll"), TEXT("翻滚角"),
	TEXT("Transform"), TEXT("变换"),
	TEXT("Location"), TEXT("位置"),
	TEXT("Rotation"), TEXT("旋转"),
	TEXT("Scale"), TEXT("缩放"),
	TEXT("Size"), TEXT("大小"),
	TEXT("Mass"), TEXT("质量"),
	TEXT("Speed"), TEXT("速度"),
	TEXT("Velocity"), TEXT("速度"),
	TEXT("Acceleration"), TEXT("加速度"),
	TEXT("Force"), TEXT("力"),
	TEXT("Gravity"), TEXT("重力"),
	TEXT("Drag Coefficient"), TEXT("阻力系数"),
	TEXT("Friction"), TEXT("摩擦力"),
	TEXT("Restitution"), TEXT("弹性系数"),
	TEXT("Damping"), TEXT("阻尼"),
	TEXT("Stiffness"), TEXT("刚度"),
	TEXT("Frequency"), TEXT("频率"),
	TEXT("Amplitude"), TEXT("振幅"),
	TEXT("Period"), TEXT("周期"),
	TEXT("Phase"), TEXT("相位"),
	TEXT("Offset"), TEXT("偏移"),
	TEXT("Range"), TEXT("范围"),
	TEXT("Minimum"), TEXT("最小值"),
	TEXT("Maximum"), TEXT("最大值"),
	TEXT("Rate"), TEXT("速率"),
	TEXT("Count"), TEXT("数量"),
	TEXT("Amount"), TEXT("数量"),
	TEXT("Weight"), TEXT("权重"),
	TEXT("Priority"), TEXT("优先级"),
	TEXT("Quality"), TEXT("质量"),
	TEXT("Resolution"), TEXT("分辨率"),
	TEXT("Precision"), TEXT("精度"),
	TEXT("Tolerance"), TEXT("容差"),
	TEXT("Threshold"), TEXT("阈值"),
	TEXT("Falloff"), TEXT("衰减"),
	TEXT("Exponent"), TEXT("指数"),
	TEXT("Multiplier"), TEXT("乘数"),
	TEXT("Divider"), TEXT("除数"),
	TEXT("Bias"), TEXT("偏差"),

	// Dynamic Inputs — Math / Conversion
	TEXT("Abs Float"), TEXT("绝对值浮点"),
	TEXT("Negate Vector"), TEXT("取反向量"),
	TEXT("One Minus Float"), TEXT("一减浮点"),
	TEXT("Power"), TEXT("幂"),
	TEXT("Safe Normalize Vector"), TEXT("安全归一化向量"),
	TEXT("Nlerp"), TEXT("归一化线性插值"),
	TEXT("Scale and Bias Float"), TEXT("缩放与偏置浮点"),
	TEXT("Scale and Bias a Vector"), TEXT("缩放与偏置向量"),
	TEXT("Set Bool by Float Comparison"), TEXT("浮点比较设置布尔"),
	TEXT("Set Bool by Int Comparison"), TEXT("整数比较设置布尔"),
	TEXT("Uniform a or B Float"), TEXT("均匀 A 或 B 浮点"),
	TEXT("Waveform"), TEXT("波形"),
	TEXT("Derive Z"), TEXT("推导 Z 值"),

	// Dynamic Inputs — Type conversion
	TEXT("Break Linear Color"), TEXT("分解线性颜色"),
	TEXT("Break Vector"), TEXT("分解向量"),
	TEXT("Break Vector 2D"), TEXT("分解二维向量"),
	TEXT("Break Vector 4"), TEXT("分解四维向量"),
	TEXT("Convert Position to Vector"), TEXT("位置转向量"),
	TEXT("Convert Vector to Position"), TEXT("向量转位置"),
	TEXT("Angle Conversion"), TEXT("角度转换"),
	TEXT("Degrees to Radians"), TEXT("度转弧度"),
	TEXT("Radians to Degrees"), TEXT("弧度转度"),
	TEXT("Degrees to Normalized Angle"), TEXT("度转归一化角度"),
	TEXT("Normalized Angle to Degrees"), TEXT("归一化角度转度"),
	TEXT("Normalized Angle to Radians"), TEXT("归一化角度转弧度"),
	TEXT("Radians to Normalized Angle"), TEXT("弧度转归一化角度"),
	TEXT("Float to Int"), TEXT("浮点转整数"),
	TEXT("Int from Bool"), TEXT("布尔转整数"),
	TEXT("Float from Bool"), TEXT("布尔转浮点"),

	// Dynamic Inputs — Distance / Camera / ID
	TEXT("Distance Between Positions"), TEXT("位置间距"),
	TEXT("Distance to Camera"), TEXT("到摄像机距离"),
	TEXT("Calculate Particle Radius"), TEXT("计算粒子半径"),
	TEXT("Calculate Radius from Sprite Size"), TEXT("从 Sprite 大小计算半径"),
	TEXT("Calculate the Volume of a Box"), TEXT("计算盒体体积"),
	TEXT("Camera Fade"), TEXT("摄像机淡出"),
	TEXT("Return Camera Position"), TEXT("返回摄像机位置"),
	TEXT("Return Camera Property"), TEXT("返回摄像机属性"),
	TEXT("Return Camera Vector"), TEXT("返回摄像机向量"),
	TEXT("Return Particle ID"), TEXT("返回粒子 ID"),
	TEXT("Return Exec Index"), TEXT("返回执行索引"),
	TEXT("Return Normalized Exec Index"), TEXT("返回归一化执行索引"),
	TEXT("Return Largest Float"), TEXT("返回最大浮点"),
	TEXT("Return Mesh Orientation Axis"), TEXT("返回网格体朝向轴"),
	TEXT("Generate Int from Counter"), TEXT("从计数器生成整数"),

	// Dynamic Inputs — Mesh / Socket
	TEXT("Get Mesh Bounds"), TEXT("获取网格体边界"),
	TEXT("Get Mesh Renderer Radius"), TEXT("获取网格体渲染器半径"),
	TEXT("Get Vertex Count"), TEXT("获取顶点数"),
	TEXT("Specific Bone"), TEXT("指定骨骼"),
	TEXT("Specific Socket"), TEXT("指定插槽"),
	TEXT("Random Specific Bone"), TEXT("随机指定骨骼"),
	TEXT("Random Specific Socket"), TEXT("随机指定插槽"),

	// Dynamic Inputs — Array / Spawn Group
	TEXT("Spawn Group"), TEXT("生成组"),
	TEXT("Select Float from Array"), TEXT("从数组选择浮点"),
	TEXT("Select Int from Array"), TEXT("从数组选择整数"),
	TEXT("Select Vector from Array"), TEXT("从数组选择向量"),
	TEXT("Select Position from Array"), TEXT("从数组选择位置"),
	TEXT("Get Float Array Count"), TEXT("获取浮点数组计数"),
	TEXT("Get Vector Array Count"), TEXT("获取向量数组计数"),
	TEXT("Mask Bool by Spawn Group"), TEXT("按生成组遮罩布尔"),
	TEXT("Mask Float by Spawn Group"), TEXT("按生成组遮罩浮点"),
	TEXT("Mask Vector by Spawn Group"), TEXT("按生成组遮罩向量"),

	// Dynamic Inputs — Transform / Rotate
	TEXT("Rotate Vector"), TEXT("旋转向量"),
	TEXT("Rotate Vector by Quaternion"), TEXT("四元数旋转向量"),
	TEXT("Transform Position"), TEXT("变换位置"),
	TEXT("Transform Vector"), TEXT("变换向量"),

	// Dynamic Inputs — Comparison / Simulation
	TEXT("Compare Floats"), TEXT("比较浮点"),
	TEXT("Simulation Position"), TEXT("模拟位置"),
	TEXT("Hue Shift Linear Color"), TEXT("色相偏移线性颜色"),
	TEXT("Invert Quaternion"), TEXT("反转四元数"),
	TEXT("Fixed Seed Random Float"), TEXT("固定种子随机浮点"),
	TEXT("Find Mid Point Between Positions"), TEXT("查找位置中点"),
	TEXT("Find Mid Point Between Vectors"), TEXT("查找向量中点"),
	TEXT("Find Quat Between Two Vectors"), TEXT("查找两向量间四元数"),
	TEXT("Scalability Distance Based Float"), TEXT("可扩展性距离浮点"),
	TEXT("Scalability Distance Based Vector"), TEXT("可扩展性距离向量"),
	TEXT("Is Platform Set Active"), TEXT("平台设置是否活跃"),
	TEXT("BaryCentric Coord from Triangle Coordinate"), TEXT("三角形坐标转重心坐标"),
	TEXT("Triangle Index from Triangle Coordinate"), TEXT("三角形坐标转三角形索引"),

	// Distribution types
	TEXT("Uniform Distribution"), TEXT("均匀分布"),
	TEXT("Gaussian Distribution"), TEXT("高斯分布"),
	TEXT("Random Distribution"), TEXT("随机分布"),
	TEXT("Constant Curve"), TEXT("常量曲线"),
	TEXT("Uniform Curve"), TEXT("均匀曲线"),
	TEXT("Random Curve"), TEXT("随机曲线"),
	TEXT("User Curve"), TEXT("用户曲线"),
	TEXT("Float from Curve"), TEXT("曲线浮点值"),

	// Detail Panel — Distribution types
	TEXT("Distribution"), TEXT("分布"),
	TEXT("Uniform Distribution"), TEXT("均匀分布"),
	TEXT("Gaussian Distribution"), TEXT("高斯分布"),
	TEXT("Random Distribution"), TEXT("随机分布"),
	TEXT("Random Range"), TEXT("随机范围"),
	TEXT("Random Uniform"), TEXT("随机均匀"),
	TEXT("Random Range Float"), TEXT("随机范围浮点"),
	TEXT("Random Range Vector"), TEXT("随机范围向量"),
	TEXT("Random Uniform Float"), TEXT("随机均匀浮点"),
	TEXT("Random Uniform Vector"), TEXT("随机均匀向量"),
	TEXT("Constant Curve"), TEXT("常量曲线"),
	TEXT("Uniform Curve"), TEXT("均匀曲线"),
	TEXT("Random Curve"), TEXT("随机曲线"),
	TEXT("User Curve"), TEXT("用户曲线"),
	TEXT("Float from Curve"), TEXT("曲线浮点值"),
	TEXT("Float from Uniform Curve"), TEXT("均匀曲线浮点值"),
	TEXT("Vector from Curve"), TEXT("曲线向量值"),

	// Detail Panel — Modes / Operations
	TEXT("Direct Set"), TEXT("直接设置"),
	TEXT("Add"), TEXT("加"),
	TEXT("Subtract"), TEXT("减"),
	TEXT("Multiply"), TEXT("乘"),
	TEXT("Divide"), TEXT("除"),
	TEXT("Override"), TEXT("覆盖"),
	TEXT("Inherit"), TEXT("继承"),
	TEXT("Blend"), TEXT("混合"),
	TEXT("Replace"), TEXT("替换"),
	TEXT("Minimum"), TEXT("最小值"),
	TEXT("Maximum"), TEXT("最大值"),
	TEXT("Average"), TEXT("平均值"),
	TEXT("Sum"), TEXT("求和"),
	TEXT("Linear"), TEXT("线性"),
	TEXT("Spherical"), TEXT("球形"),
	TEXT("Cylindrical"), TEXT("圆柱形"),
	TEXT("Radial"), TEXT("径向"),
	TEXT("Vortex"), TEXT("旋涡"),
	TEXT("Turbulence"), TEXT("湍流"),

	// Detail Panel — Coordinate Spaces
	TEXT("Local Space"), TEXT("局部空间"),
	TEXT("World Space"), TEXT("世界空间"),
	TEXT("Simulation Space"), TEXT("模拟空间"),
	TEXT("Emitter Space"), TEXT("发射器空间"),
	TEXT("Particle Space"), TEXT("粒子空间"),
	TEXT("Screen Space"), TEXT("屏幕空间"),
	TEXT("UV Space"), TEXT("UV 空间"),
	TEXT("Local"), TEXT("局部"),
	TEXT("World"), TEXT("世界"),
	TEXT("Simulation"), TEXT("模拟"),

	// Detail Panel — Axis / Channel
	TEXT("Axis"), TEXT("轴"),
	TEXT("X Axis"), TEXT("X 轴"),
	TEXT("Y Axis"), TEXT("Y 轴"),
	TEXT("Z Axis"), TEXT("Z 轴"),
	TEXT("X Channel"), TEXT("X 通道"),
	TEXT("Y Channel"), TEXT("Y 通道"),
	TEXT("Z Channel"), TEXT("Z 通道"),
	TEXT("W Channel"), TEXT("W 通道"),
	TEXT("Red Channel"), TEXT("红色通道"),
	TEXT("Green Channel"), TEXT("绿色通道"),
	TEXT("Blue Channel"), TEXT("蓝色通道"),
	TEXT("Alpha Channel"), TEXT("透明通道"),
	TEXT("Horizontal"), TEXT("水平"),
	TEXT("Vertical"), TEXT("垂直"),

	// Detail Panel — Common Properties
	TEXT("Mass Mode"), TEXT("质量模式"),
	TEXT("Drag Coefficient"), TEXT("阻力系数"),
	TEXT("Restitution"), TEXT("弹性系数"),
	TEXT("Friction"), TEXT("摩擦力"),
	TEXT("Damping"), TEXT("阻尼"),
	TEXT("Stiffness"), TEXT("刚度"),
	TEXT("Spring Constant"), TEXT("弹簧常数"),
	TEXT("Rest Length"), TEXT("静止长度"),
	TEXT("Lifetime Mode"), TEXT("生命周期模式"),
	TEXT("Normalized Age"), TEXT("归一化年龄"),
	TEXT("Particle Index"), TEXT("粒子索引"),
	TEXT("Spawn Interpolation"), TEXT("生成插值"),
	TEXT("Ribbon ID"), TEXT("条带 ID"),
	TEXT("Ribbon Width"), TEXT("条带宽度"),
	TEXT("Particle Random"), TEXT("粒子随机"),
	TEXT("Per Particle"), TEXT("每粒子"),
	TEXT("Per Module"), TEXT("每模块"),
	TEXT("Per Emitter"), TEXT("每发射器"),
	TEXT("Per System"), TEXT("每系统"),
	TEXT("Execution Index"), TEXT("执行索引"),
	TEXT("Normalized Execution Index"), TEXT("归一化执行索引"),
	TEXT("Determinism"), TEXT("确定性"),
	TEXT("Interpolation Mode"), TEXT("插值模式"),

	// Detail Panel — Common Values
	TEXT("Surface"), TEXT("表面"),
	TEXT("Volume"), TEXT("体积"),
	TEXT("Hemisphere"), TEXT("半球"),
	TEXT("Uniform"), TEXT("均匀"),
	TEXT("Random"), TEXT("随机"),
	TEXT("Non-Uniform"), TEXT("非均匀"),
	TEXT("Closest"), TEXT("最近"),
	TEXT("Enabled"), TEXT("启用"),
	TEXT("Disabled"), TEXT("禁用"),
	TEXT("Shown"), TEXT("显示"),
	TEXT("Collapsed"), TEXT("折叠"),
	TEXT("Expand"), TEXT("展开"),
	TEXT("Farthest"), TEXT("最远"),
	TEXT("Highest"), TEXT("最高"),
	TEXT("Lowest"), TEXT("最低"),
	TEXT("Nearest"), TEXT("最接近"),
	TEXT("Linear"), TEXT("线性"),
	TEXT("Smooth"), TEXT("平滑"),
	TEXT("Cubic"), TEXT("三次方"),
	TEXT("Quadratic"), TEXT("二次方"),
	TEXT("Exponential"), TEXT("指数"),
	TEXT("Logarithmic"), TEXT("对数"),
	TEXT("Constant"), TEXT("常量"),
	TEXT("Curve"), TEXT("曲线"),
	TEXT("Direct"), TEXT("直接"),
	TEXT("Indirect"), TEXT("间接"),
	TEXT("Additive"), TEXT("叠加"),
	TEXT("Multiplicative"), TEXT("相乘"),
	TEXT("Replace"), TEXT("替换"),
	TEXT("Blend"), TEXT("混合"),
	TEXT("Mix"), TEXT("混合"),
	TEXT("Absolute"), TEXT("绝对"),
	TEXT("Relative"), TEXT("相对"),
	TEXT("Local"), TEXT("局部"),
	TEXT("World"), TEXT("世界"),
	TEXT("Screen"), TEXT("屏幕"),
	TEXT("Vertical"), TEXT("垂直"),
	TEXT("Horizontal"), TEXT("水平"),
	TEXT("Forward"), TEXT("前方"),
	TEXT("Backward"), TEXT("后方"),
	TEXT("Left"), TEXT("左"),
	TEXT("Right"), TEXT("右"),
	TEXT("Up"), TEXT("上"),
	TEXT("Down"), TEXT("下"),
	TEXT("Inside"), TEXT("内部"),
	TEXT("Outside"), TEXT("外部"),
	TEXT("Center"), TEXT("中心"),
	TEXT("Edge"), TEXT("边缘"),
	TEXT("Corner"), TEXT("角落"),
	TEXT("Top"), TEXT("顶部"),
	TEXT("Bottom"), TEXT("底部"),
	TEXT("Side"), TEXT("侧面"),
	TEXT("Front"), TEXT("前面"),
	TEXT("Back"), TEXT("后面"),

	// Color values
	TEXT("sRGB"), TEXT("sRGB"),
	TEXT("HSV"), TEXT("HSV"),
	TEXT("RGB"), TEXT("RGB"),
	TEXT("HSL"), TEXT("HSL"),
	TEXT("CMYK"), TEXT("CMYK"),

	// Types
	TEXT("Primitive"), TEXT("图元"),
	TEXT("Struct"), TEXT("结构体"),
	TEXT("Enum"), TEXT("枚举"),

	// Operations
	TEXT("Fade In"), TEXT("淡入"),
	TEXT("Fade Out"), TEXT("淡出"),
	TEXT("Enabled"), TEXT("已启用"),
	TEXT("Disabled"), TEXT("已禁用"),
	TEXT("Visible"), TEXT("可见"),
	TEXT("Hidden"), TEXT("隐藏"),
	TEXT("Default"), TEXT("默认"),
	TEXT("Custom"), TEXT("自定义"),
	TEXT("Duplicate"), TEXT("复制"),
	TEXT("Rename"), TEXT("重命名"),
	TEXT("Delete"), TEXT("删除"),
	TEXT("Cancel"), TEXT("取消"),
	TEXT("Export"), TEXT("导出"),
	TEXT("Import"), TEXT("导入"),
	TEXT("Compile"), TEXT("编译"),
	TEXT("Search"), TEXT("搜索"),
	TEXT("Filter"), TEXT("筛选"),
	TEXT("Apply"), TEXT("应用"),
	TEXT("Reset"), TEXT("重置"),
	TEXT("Close"), TEXT("关闭"),
	TEXT("Paste"), TEXT("粘贴"),
	TEXT("Save"), TEXT("保存"),
	TEXT("Load"), TEXT("加载"),
	TEXT("Open"), TEXT("打开"),
	TEXT("Copy"), TEXT("拷贝"),
	TEXT("Undo"), TEXT("撤销"),
	TEXT("Redo"), TEXT("重做"),
	TEXT("None"), TEXT("无"),
	TEXT("True"), TEXT("是"),
	TEXT("False"), TEXT("否"),

	// Detail Panel — Binding / Link
	TEXT("Binding"), TEXT("绑定"),
	TEXT("Bound to constant value"), TEXT("绑定到常量值"),
	TEXT("Bound to parameter"), TEXT("绑定到参数"),
	TEXT("Bind to the Niagara Variable"), TEXT("绑定到 Niagara 变量"),
	TEXT("Bind to the User Parameter"), TEXT("绑定到用户参数"),
	TEXT("Break Link"), TEXT("断开链接"),
	TEXT("Break Link To"), TEXT("断开链接到"),
	TEXT("Break all inner links"), TEXT("断开所有内部链接"),
	TEXT("Linked Input"), TEXT("链接输入"),
	TEXT("Link Input"), TEXT("链接输入"),
	TEXT("Link"), TEXT("链接"),
	TEXT("Expose"), TEXT("暴露"),
	TEXT("Exposed"), TEXT("已暴露"),
	TEXT("Unexpose"), TEXT("取消暴露"),
	TEXT("Dynamic Input"), TEXT("动态输入"),
	TEXT("Scratch Pad Module"), TEXT("暂存区模块"),
	TEXT("New Local Variable"), TEXT("新建局部变量"),
	TEXT("Local Variable"), TEXT("局部变量"),
	TEXT("Local Variables"), TEXT("局部变量"),
	TEXT("Create New Variable"), TEXT("创建新变量"),
	TEXT("Create Variable"), TEXT("创建变量"),
	TEXT("User Parameter"), TEXT("用户参数"),
	TEXT("User Parameters"), TEXT("用户参数"),
	TEXT("User Exposed"), TEXT("用户暴露"),
	TEXT("Parameter Binding"), TEXT("参数绑定"),
	TEXT("Input Binding"), TEXT("输入绑定"),
	TEXT("Variable Binding"), TEXT("变量绑定"),

	// Detail Panel — Module / Stack Actions
	TEXT("Add Module"), TEXT("添加模块"),
	TEXT("Remove Module"), TEXT("移除模块"),
	TEXT("Enable Module"), TEXT("启用模块"),
	TEXT("Disable Module"), TEXT("禁用模块"),
	TEXT("Move Up"), TEXT("上移"),
	TEXT("Move Down"), TEXT("下移"),
	TEXT("Move to Spawn"), TEXT("移至生成"),
	TEXT("Move to Update"), TEXT("移至更新"),
	TEXT("Insert Above"), TEXT("上方插入"),
	TEXT("Insert Below"), TEXT("下方插入"),
	TEXT("Expand All"), TEXT("全部展开"),
	TEXT("Collapse All"), TEXT("全部折叠"),
	TEXT("Expand Children"), TEXT("展开子项"),
	TEXT("Duplicate Module"), TEXT("复制模块"),
	TEXT("Disassemble Module"), TEXT("拆解模块"),
	TEXT("Promote to Emitter"), TEXT("提升为发射器"),
	TEXT("Rename Parameter"), TEXT("重命名参数"),
	TEXT("Edit Module"), TEXT("编辑模块"),
	TEXT("Reset to Default"), TEXT("重置为默认"),
	TEXT("Reset All"), TEXT("全部重置"),
	TEXT("Pin to Graph"), TEXT("固定到图表"),
	TEXT("Unpin from Graph"), TEXT("从图表取消固定"),

	// Detail Panel — Editor UI
	TEXT("Auto-Compile"), TEXT("自动编译"),
	TEXT("Auto-Compile Options"), TEXT("自动编译选项"),
	TEXT("Automatically compile when graph changes"), TEXT("图表变化时自动编译"),
	TEXT("Bake"), TEXT("烘焙"),
	TEXT("Baker"), TEXT("烘焙器"),
	TEXT("Bake Quality Level"), TEXT("烘焙质量等级"),
	TEXT("Available"), TEXT("可用"),
	TEXT("Not Available"), TEXT("不可用"),
	TEXT("Missing"), TEXT("缺失"),
	TEXT("Required"), TEXT("必需"),
	TEXT("Optional"), TEXT("可选"),
	TEXT("Recommended"), TEXT("推荐"),
	TEXT("Break"), TEXT("断开"),
	TEXT("Browse"), TEXT("浏览"),
	TEXT("Browse to Asset"), TEXT("浏览到资产"),
	TEXT("Browse to Exported Assets"), TEXT("浏览到导出资产"),
	TEXT("Filter"), TEXT("筛选"),
	TEXT("Asset Type Filtering"), TEXT("资产类型筛选"),
	TEXT("All"), TEXT("全部"),
	TEXT("An attribute is missing"), TEXT("属性缺失"),
	TEXT("Avg"), TEXT("平均"),
	TEXT("Bottom"), TEXT("底部"),
	TEXT("Top"), TEXT("顶部"),
	TEXT("Left"), TEXT("左侧"),
	TEXT("Right"), TEXT("右侧"),
	TEXT("Center"), TEXT("居中"),
	TEXT("Before"), TEXT("之前"),
	TEXT("After"), TEXT("之后"),
	TEXT("Back"), TEXT("后退"),
	TEXT("Forward"), TEXT("前进"),
	TEXT("Previous"), TEXT("上一个"),
	TEXT("Next"), TEXT("下一个"),
	TEXT("First"), TEXT("首个"),
	TEXT("Last"), TEXT("末个"),
	TEXT("Oldest"), TEXT("最旧"),
	TEXT("Newest"), TEXT("最新"),
	TEXT("Assembly"), TEXT("程序集"),
	TEXT("Blueprint"), TEXT("蓝图"),
	TEXT("Variable"), TEXT("变量"),
	TEXT("Variables"), TEXT("变量"),
	TEXT("Value"), TEXT("值"),
	TEXT("Input"), TEXT("输入"),
	TEXT("Output"), TEXT("输出"),
	TEXT("Both"), TEXT("两者"),
	TEXT("Source"), TEXT("来源"),
	TEXT("Target"), TEXT("目标"),
	TEXT("Type"), TEXT("类型"),
	TEXT("Category"), TEXT("分类"),
	TEXT("Categories"), TEXT("分类"),
	TEXT("Section"), TEXT("节"),
	TEXT("Sections"), TEXT("节"),
	TEXT("Index"), TEXT("索引"),
	TEXT("Count"), TEXT("计数"),
	TEXT("Order"), TEXT("顺序"),
	TEXT("Version"), TEXT("版本"),
	TEXT("Major Version"), TEXT("主版本"),
	TEXT("Minor Version"), TEXT("次版本"),
	TEXT("Platform"), TEXT("平台"),
	TEXT("Quality Level"), TEXT("质量等级"),
	TEXT("Reference"), TEXT("引用"),
	TEXT("Dependency"), TEXT("依赖"),
	TEXT("Dependencies"), TEXT("依赖"),
	TEXT("Owner"), TEXT("所有者"),
	TEXT("Component"), TEXT("组件"),

	// Detail Panel — View / Display
	TEXT("Show in Overview"), TEXT("在概览中显示"),
	TEXT("Show in Graph"), TEXT("在图表中显示"),
	TEXT("Show in Timeline"), TEXT("在时间轴中显示"),
	TEXT("Show Advanced"), TEXT("显示高级"),
	TEXT("Hide Advanced"), TEXT("隐藏高级"),
	TEXT("Show Only Used"), TEXT("仅显示已使用"),
	TEXT("Show All"), TEXT("显示全部"),
	TEXT("Compact Mode"), TEXT("紧凑模式"),
	TEXT("Full Mode"), TEXT("完整模式"),
	TEXT("Thumbnail"), TEXT("缩略图"),
	TEXT("List View"), TEXT("列表视图"),
	TEXT("Tile View"), TEXT("平铺视图"),
	TEXT("Icon"), TEXT("图标"),
	TEXT("Label"), TEXT("标签"),
	TEXT("Tooltip"), TEXT("提示框"),
	TEXT("Notification"), TEXT("通知"),
	TEXT("Confirm"), TEXT("确认"),
	TEXT("Cancel"), TEXT("取消"),
	TEXT("OK"), TEXT("确定"),
	TEXT("Yes"), TEXT("是"),
	TEXT("No"), TEXT("否"),
	TEXT("On"), TEXT("开"),
	TEXT("Off"), TEXT("关"),

	// Detail Panel — Render / Display
	TEXT("Facing Mode"), TEXT("朝向模式"),
	TEXT("Sort Mode"), TEXT("排序模式"),
	TEXT("Blend Mode"), TEXT("混合模式"),
	TEXT("Alignment Mode"), TEXT("对齐模式"),
	TEXT("Sprite Facing"), TEXT("Sprite 朝向"),
	TEXT("Sprite Alignment"), TEXT("Sprite 对齐"),
	TEXT("Pivot Offset"), TEXT("锚点偏移"),
	TEXT("Pivot Offset Unit"), TEXT("锚点偏移单位"),
	TEXT("Renderer"), TEXT("渲染器"),
	TEXT("Renderers"), TEXT("渲染器"),
	TEXT("Render"), TEXT("渲染"),
	TEXT("Mesh"), TEXT("网格体"),
	TEXT("Sprite"), TEXT("Sprite"),
	TEXT("Ribbon"), TEXT("条带"),
	TEXT("Light"), TEXT("光源"),
	TEXT("Decal"), TEXT("贴花"),
	TEXT("Camera"), TEXT("摄像机"),
	TEXT("View"), TEXT("视图"),
	TEXT("Viewport"), TEXT("视口"),

	// Detail Panel — Module Types
	TEXT("Module"), TEXT("模块"),
	TEXT("Modules"), TEXT("模块"),
	TEXT("Function"), TEXT("函数"),
	TEXT("Template"), TEXT("模板"),
	TEXT("Parent Emitter"), TEXT("父发射器"),
	TEXT("Event Handler"), TEXT("事件处理器"),
	TEXT("Event Handlers"), TEXT("事件处理器"),
	TEXT("Simulation Stage"), TEXT("模拟阶段"),
	TEXT("Simulation Stages"), TEXT("模拟阶段"),
	TEXT("Stage"), TEXT("阶段"),
	TEXT("Stages"), TEXT("阶段"),
	TEXT("Stack Group"), TEXT("栈组"),
	TEXT("Stack"), TEXT("栈"),

	// Detail Panel — Memory / Performance
	TEXT("Memory"), TEXT("内存"),
	TEXT("Performance"), TEXT("性能"),
	TEXT("GPU"), TEXT("GPU"),
	TEXT("CPU"), TEXT("CPU"),
	TEXT("Tick"), TEXT("Tick"),
	TEXT("Frame"), TEXT("帧"),
	TEXT("FPS"), TEXT("帧率"),
	TEXT("Latency"), TEXT("延迟"),
	TEXT("Budget"), TEXT("预算"),
	TEXT("Profile"), TEXT("性能分析"),
	TEXT("Statistics"), TEXT("统计"),
	TEXT("Summary"), TEXT("摘要"),
	TEXT("Overview"), TEXT("概览"),
	TEXT("Graph"), TEXT("图表"),
	TEXT("Node Graph"), TEXT("节点图表"),
	TEXT("Hierarchy"), TEXT("层级"),
	TEXT("Tree"), TEXT("树"),
	TEXT("List"), TEXT("列表"),
	TEXT("Array"), TEXT("数组"),
	TEXT("Element"), TEXT("元素"),
	TEXT("Elements"), TEXT("元素"),
	TEXT("Item"), TEXT("项"),
	TEXT("Items"), TEXT("项"),
	TEXT("Row"), TEXT("行"),
	TEXT("Column"), TEXT("列"),
	TEXT("Cell"), TEXT("单元格"),

	nullptr
};

void FNiagaraCNModule::BuildDictionary()
{
	EnToZh.Empty();

	TArray<TPair<FString,FString>> Pairs;
	int32 i = 0;
	while (RawPairs[i])
	{
		Pairs.Add(TPair<FString,FString>(FString(RawPairs[i]).TrimStartAndEnd(), FString(RawPairs[i+1])));
		i += 2;
	}

	Pairs.Sort([](const TPair<FString,FString>& A, const TPair<FString,FString>& B)
	{
		int32 LenA = A.Key.Len();
		int32 LenB = B.Key.Len();
		if (LenA != LenB) return LenA > LenB;
		return A.Key < B.Key;
	});

	for (auto& P : Pairs)
	{
		EnToZh.Add(P.Key, P.Value);
	}

	UE_LOG(LogNiagaraCN, Log, TEXT("词典已加载：%d 条"), EnToZh.Num());
}

// ============================================================
//  Module lifecycle
// ============================================================
FNiagaraCNModule& FNiagaraCNModule::Get()
{
	return FModuleManager::LoadModuleChecked<FNiagaraCNModule>("NiagaraCN");
}

bool FNiagaraCNModule::IsEnabled()
{
	return bEnabled;
}

void FNiagaraCNModule::SetEnabled(bool bEnable)
{
	if (bEnable == bEnabled) return;
	bEnabled = bEnable;

	FNiagaraCNTextSource::SetEnabled(bEnable);

	if (bEnable)
	{
		FTextLocalizationManager::Get().RefreshResources();
		Get().TranslateAllStackEntries();
		Get().StartStackEntryScan();
	}
	else
	{
		if (GStackEntryScanHandle.IsValid())
		{
			FTSTicker::GetCoreTicker().RemoveTicker(GStackEntryScanHandle);
			GStackEntryScanHandle.Reset();
		}
		Get().RestoreAllStackEntries();
		FTextLocalizationManager::Get().RefreshResources();
	}

	UE_LOG(LogNiagaraCN, Log, TEXT("翻译%s"), bEnable ? TEXT("已启用") : TEXT("已禁用"));
}

void FNiagaraCNModule::StartupModule()
{
	BuildDictionary();
	RegisterToolbarToggle();
	RegisterTextSource();
	StartStackEntryScan();

	GAddModuleSearchHandle = FTSTicker::GetCoreTicker().AddTicker(
		FTickerDelegate::CreateStatic(&AddModuleSearchTick), 0.0f);

	UE_LOG(LogNiagaraCN, Log, TEXT("Niagara 中文翻译伴侣已启动 (FText管道 + 栈条目AlternateDisplayName + 渲染回调)"));
}

void FNiagaraCNModule::ShutdownModule()
{
	bEnabled = false;
	FNiagaraCNTextSource::SetEnabled(false);

	// CRITICAL: Remove tickers FIRST to stop any in-flight UObject iteration
	if (GStackEntryScanHandle.IsValid())
	{
		FTSTicker::GetCoreTicker().RemoveTicker(GStackEntryScanHandle);
		GStackEntryScanHandle.Reset();
	}
	if (GAddModuleSearchHandle.IsValid())
	{
		FTSTicker::GetCoreTicker().RemoveTicker(GAddModuleSearchHandle);
		GAddModuleSearchHandle.Reset();
	}

	// Release the text source.  FTextLocalizationManager holds its own shared
	// reference, so the object lives until the manager shuts down naturally.
	TextSource.Reset();

	// Remove toolbar extender from NiagaraEditor
	if (NiagaraToolbarExtender.IsValid())
	{
		if (FNiagaraEditorModule* NiagaraModule = FModuleManager::GetModulePtr<FNiagaraEditorModule>("NiagaraEditor"))
		{
			TSharedPtr<FExtensibilityManager> Mgr = NiagaraModule->GetToolBarExtensibilityManager();
			if (Mgr.IsValid())
			{
				Mgr->RemoveExtender(NiagaraToolbarExtender);
			}
		}
		NiagaraToolbarExtender.Reset();
	}

	// DO NOT call RestoreAllStackEntries() or RefreshResources() here.
	// During shutdown UObjects are being destroyed and iterating them will
	// crash.  Any AlternateDisplayName overrides die with the editor anyway.
}

void FNiagaraCNModule::RegisterTextSource()
{
	if (TextSource.IsValid()) return;

	TextSource = MakeShared<FNiagaraCNTextSource>(EnToZh);
	FTextLocalizationManager::Get().RegisterTextSource(TextSource.ToSharedRef(), true);
	UE_LOG(LogNiagaraCN, Log, TEXT("已注册 FText 翻译源（%d 词条）"), EnToZh.Num());
}

// ============================================================
//  Stack-entry-level translation via AlternateDisplayName
//  Uses UNiagaraStackEditorData::SetStackEntryDisplayName()
//  to set persistent alternate names, then triggers a full
//  stack refresh.  The SNiagaraStackDisplayName widget already
//  checks AlternateDisplayName before GetDisplayName().
//
//  A periodic ticker rescans for new entries (expanded nodes,
//  added modules, etc.) and translates them.
// ============================================================

// MinimalAPI classes don't export StaticClass(), so we can't use
// TObjectIterator<T> or Cast<T>(). Check class hierarchy at runtime.
static bool IsA(UObject* Obj, const TCHAR* ClassName)
{
	for (UClass* C = Obj->GetClass(); C; C = C->GetSuperClass())
	{
		if (C->GetFName() == ClassName) return true;
	}
	return false;
}

// SetStackEntryDisplayName is not DLL-exported, so we access
// StackEntryKeyToDisplayName UPROPERTY via reflection.
static void SetDisplayNameViaReflection(UNiagaraStackEditorData& EditorData, const FString& Key, const FText& Value)
{
	static FMapProperty* MapProp = nullptr;
	if (!MapProp)
	{
		FProperty* Prop = EditorData.GetClass()->FindPropertyByName(TEXT("StackEntryKeyToDisplayName"));
		MapProp = CastField<FMapProperty>(Prop);
		if (!MapProp)
		{
			UE_LOG(LogNiagaraCN, Error, TEXT("无法找到 StackEntryKeyToDisplayName 属性"));
			return;
		}
	}

	void* MapAddr = MapProp->ContainerPtrToValuePtr<void>(&EditorData);
	FScriptMapHelper MapHelper(MapProp, MapAddr);

	if (Value.IsEmptyOrWhitespace())
	{
		int32 Idx = MapHelper.FindMapIndexWithKey(&Key);
		if (Idx != INDEX_NONE)
		{
			MapHelper.RemoveAt(Idx);
		}
	}
	else
	{
		int32 Idx = MapHelper.FindMapIndexWithKey(&Key);
		if (Idx == INDEX_NONE)
		{
			Idx = MapHelper.AddDefaultValue_Invalid_NeedsRehash();
			FString* KeyPtr = (FString*)MapHelper.GetKeyPtr(Idx);
			*KeyPtr = Key;
		}
		FText* ValuePtr = (FText*)MapHelper.GetValuePtr(Idx);
		*ValuePtr = Value;
		MapHelper.Rehash();
	}

	EditorData.OnPersistentDataChanged().Broadcast();
}

// Returns true if a translation was applied
static bool ApplyTranslationsToEntry(UNiagaraStackEntry* Entry, const TMap<FString,FString>& Dict)
{
	const FString DispStr = Entry->GetDisplayName().ToString();
	if (DispStr.IsEmpty()) return false;

	TOptional<FText> AltName = Entry->GetAlternateDisplayName();
	FString AltStr = AltName.IsSet() ? AltName.GetValue().ToString() : FString();

	UNiagaraStackEditorData& EditorData = Entry->GetStackEditorData();
	const FString Key = Entry->GetStackEditorDataKey();

	// Find translation: exact match first, then substring replacement
	FString Zh;
	if (const FString* Found = Dict.Find(DispStr))
	{
		Zh = *Found;
	}
	else
	{
		FString Result = DispStr;
		bool bChanged = false;
		for (const auto& P : Dict)
		{
			if (Result.Contains(P.Key))
			{
				Result = Result.Replace(*P.Key, *P.Value);
				bChanged = true;
			}
		}
		if (bChanged) Zh = Result;
	}

	if (Zh.IsEmpty()) return false;

	// For function inputs (parameters), use SetSummaryViewDisplayName directly
	// because their RefreshChildrenInternal() does NOT call Super, so they
	// never load AlternateDisplayName from the editor data TMap.
	if (IsA(Entry, TEXT("NiagaraStackFunctionInput")))
	{
		UNiagaraStackFunctionInput* Input = static_cast<UNiagaraStackFunctionInput*>(Entry);
		FText CurrentDisplay = Input->GetDisplayName();
		if (CurrentDisplay.ToString() != Zh)
		{
			Input->SetSummaryViewDisplayName(TAttribute<FText>(FText::FromString(Zh)));
			return true;
		}
		return false;
	}

	// For regular entries, use the editor-data AlternateDisplayName approach
	if (AltStr != Zh)
	{
		SetDisplayNameViaReflection(EditorData, Key, FText::FromString(Zh));
		return true;
	}
	return false;
}

bool FNiagaraCNModule::TranslateAllStackEntries()
{
	int32 TranslatedCount = 0;

	for (TObjectIterator<UObject> It; It; ++It)
	{
		UObject* Obj = *It;
		if (!Obj || !IsA(Obj, TEXT("NiagaraStackEntry"))) continue;

		UNiagaraStackEntry* Entry = static_cast<UNiagaraStackEntry*>(Obj);
		if (Entry->IsFinalized()) continue;

		if (ApplyTranslationsToEntry(Entry, EnToZh))
		{
			TranslatedCount++;
		}
	}

	// Trigger refresh on all stack view models — only if we actually translated something new
	if (TranslatedCount > 0)
	{
		int32 VmCount = 0;
		for (TObjectIterator<UObject> It; It; ++It)
		{
			UObject* Obj = *It;
			if (!Obj || !IsA(Obj, TEXT("NiagaraStackViewModel"))) continue;

			UNiagaraStackViewModel* VM = static_cast<UNiagaraStackViewModel*>(Obj);
			if (VM->GetRootEntry() && !VM->GetRootEntry()->IsFinalized())
			{
				VM->RequestRefreshDeferred();
				VmCount++;
			}
		}
		UE_LOG(LogNiagaraCN, Log, TEXT("栈条目翻译: %d 个新翻译, %d 个视图模型已刷新"), TranslatedCount, VmCount);
		return true;
	}
	return false;
}

void FNiagaraCNModule::RestoreAllStackEntries()
{
	// Build set of Chinese values for quick lookup
	TSet<FString> ZhValues;
	for (const auto& P : EnToZh)
	{
		ZhValues.Add(P.Value);
	}

	int32 RestoredCount = 0;
	for (TObjectIterator<UObject> It; It; ++It)
	{
		UObject* Obj = *It;
		if (!Obj || !IsA(Obj, TEXT("NiagaraStackEntry"))) continue;

		UNiagaraStackEntry* Entry = static_cast<UNiagaraStackEntry*>(Obj);
		if (Entry->IsFinalized()) continue;

		// Clear AlternateDisplayName (set via editor data TMap)
		TOptional<FText> AltName = Entry->GetAlternateDisplayName();
		if (AltName.IsSet() && ZhValues.Contains(AltName.GetValue().ToString()))
		{
			UNiagaraStackEditorData& EditorData = Entry->GetStackEditorData();
			SetDisplayNameViaReflection(EditorData, Entry->GetStackEditorDataKey(), FText::GetEmpty());
			RestoredCount++;
		}

		// Clear SummaryViewDisplayNameOverride on function inputs
		if (IsA(Obj, TEXT("NiagaraStackFunctionInput")))
		{
			UNiagaraStackFunctionInput* Input = static_cast<UNiagaraStackFunctionInput*>(Obj);
			FString DisplayStr = Input->GetDisplayName().ToString();
			if (!DisplayStr.IsEmpty())
			{
				// Check if current display name looks translated (contains Chinese)
				bool bLooksTranslated = false;
				for (const TCHAR* s = *DisplayStr; *s; ++s)
				{
					if (*s >= 0x4E00 && *s <= 0x9FFF) { bLooksTranslated = true; break; }
				}
				if (bLooksTranslated)
				{
					Input->SetSummaryViewDisplayName(TAttribute<FText>());
					RestoredCount++;
				}
			}
		}
	}

	if (RestoredCount > 0)
	{
		// Trigger refresh on all stack view models
		for (TObjectIterator<UObject> It; It; ++It)
		{
			UObject* Obj = *It;
			if (!Obj || !IsA(Obj, TEXT("NiagaraStackViewModel"))) continue;

			UNiagaraStackViewModel* VM = static_cast<UNiagaraStackViewModel*>(Obj);
			if (VM->GetRootEntry() && !VM->GetRootEntry()->IsFinalized())
			{
				VM->RequestRefreshDeferred();
			}
		}
	}

	UE_LOG(LogNiagaraCN, Log, TEXT("栈条目还原: %d 个已清除"), RestoredCount);
}

void FNiagaraCNModule::StartStackEntryScan()
{
	if (GStackEntryScanHandle.IsValid())
	{
		FTSTicker::GetCoreTicker().RemoveTicker(GStackEntryScanHandle);
		GStackEntryScanHandle.Reset();
	}

	// Immediate first scan
	TranslateAllStackEntries();

	// Periodic scan every 2s. Only refreshes when new translations are found,
	// so no flashing after the initial setup.
	GStackEntryScanHandle = FTSTicker::GetCoreTicker().AddTicker(
		FTickerDelegate::CreateLambda([this](float) -> bool
		{
			if (!bEnabled)
			{
				GStackEntryScanHandle.Reset();
				return false;
			}
			// Skip expensive UObject iteration if no Niagara editor is open
			bool bHasViewModels = false;
			for (TObjectIterator<UObject> It; It; ++It)
			{
				UObject* Obj = *It;
				if (Obj && IsA(Obj, TEXT("NiagaraStackViewModel")))
				{
					UNiagaraStackViewModel* VM = static_cast<UNiagaraStackViewModel*>(Obj);
					if (VM->GetRootEntry() && !VM->GetRootEntry()->IsFinalized())
					{
						bHasViewModels = true;
						break;
					}
				}
			}
			if (bHasViewModels)
			{
				TranslateAllStackEntries();
			}
			return true;
		}),
		2.0f
	);
}

// ============================================================
//  Toolbar — Level Editor + Niagara Script Editor + Niagara System Editor
// ============================================================
static void FillNiagaraCNToolbar(FToolBarBuilder& Builder)
{
	Builder.AddToolBarButton(
		FUIAction(
			FExecuteAction::CreateLambda([](){ FNiagaraCNModule::SetEnabled(!FNiagaraCNModule::IsEnabled()); }),
			FCanExecuteAction(),
			FIsActionChecked::CreateLambda([](){ return FNiagaraCNModule::IsEnabled(); })
		),
		NAME_None,
		LOCTEXT("ToggleLabel", "中/英"),
		LOCTEXT("ToggleTip", "切换 Niagara 编辑器中文/英文显示"),
		FSlateIcon(FAppStyle::GetAppStyleSetName(), "ClassIcon.ParticleSystem"),
		EUserInterfaceActionType::ToggleButton
	);
}

void FNiagaraCNModule::RegisterToolbarToggle()
{
	// 1) Level Editor toolbar
	UToolMenu* LevelMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar.User");
	FToolMenuSection& LevelSection = LevelMenu->FindOrAddSection("NiagaraCNToggle");
	LevelSection.AddEntry(FToolMenuEntry::InitToolBarButton(
		TEXT("NiagaraCNToggle"),
		FUIAction(
			FExecuteAction::CreateLambda([](){ SetEnabled(!bEnabled); }),
			FCanExecuteAction(),
			FIsActionChecked::CreateLambda([](){ return bEnabled; })
		),
		LOCTEXT("ToggleLabel", "中/英"),
		LOCTEXT("ToggleTip", "切换 Niagara 编辑器中文/英文显示"),
		FSlateIcon(FAppStyle::GetAppStyleSetName(), "ClassIcon.ParticleSystem"),
		EUserInterfaceActionType::ToggleButton
	));

	// 2) Niagara Script Editor toolbar
	UToolMenu* ScriptToolbar = UToolMenus::Get()->ExtendMenu("AssetEditor.NiagaraScriptEditor.ToolBar");
	if (ScriptToolbar)
	{
		FToolMenuSection& ScriptSection = ScriptToolbar->FindOrAddSection("NiagaraCN");
		ScriptSection.AddEntry(FToolMenuEntry::InitToolBarButton(
			TEXT("NiagaraCNToggle_Script"),
			FUIAction(
				FExecuteAction::CreateLambda([](){ SetEnabled(!bEnabled); }),
				FCanExecuteAction(),
				FIsActionChecked::CreateLambda([](){ return bEnabled; })
			),
			LOCTEXT("ToggleLabel", "中/英"),
			LOCTEXT("ToggleTip", "切换中/英文显示"),
			FSlateIcon(FAppStyle::GetAppStyleSetName(), "ClassIcon.ParticleSystem"),
			EUserInterfaceActionType::ToggleButton
		));
	}

	// 3) Niagara System/Emitter Editor toolbar
	FNiagaraEditorModule* NiagaraModule = FModuleManager::GetModulePtr<FNiagaraEditorModule>("NiagaraEditor");
	if (NiagaraModule)
	{
		NiagaraToolbarExtender = MakeShareable(new FExtender);
		NiagaraToolbarExtender->AddToolBarExtension(
			"Asset",
			EExtensionHook::After,
			nullptr,
			FToolBarExtensionDelegate::CreateStatic(&FillNiagaraCNToolbar)
		);
		NiagaraModule->GetToolBarExtensibilityManager()->AddExtender(NiagaraToolbarExtender);
	}
}

// ============================================================
//  Add Module Window — display translation (v1.1)
//  Directly modifies FNiagaraMenuAction_Generic items:
//   - DisplayName → Chinese (display + Chinese search)
//   - Keywords += English name (English search)
//  No STextBlock scanning needed — actions are translated at the
//  data source, so virtual-list scrolling just works.
// ============================================================

static bool ContainsChinese(const FString& Text)
{
	for (const TCHAR& Ch : Text)
	{
		if (Ch >= 0x4E00 && Ch <= 0x9FFF) return true;
	}
	return false;
}

// Hack to access SNiagaraActionWidget's private ActionPtr.
// Memory layout must match — if this breaks after engine update, fix here.
struct SNiagaraActionWidgetHack : public SCompoundWidget
{
	TSharedPtr<FNiagaraMenuAction_Generic> ActionPtr;
	// ... other members we don't care about
};

static void TranslateMenuItem(TSharedRef<SWidget> Widget, const TMap<FString,FString>& EnToZh,
	int32& OutTranslated, int32& InOutVisited, int32 MaxVisited, int32 Depth = 50)
{
	if (Depth <= 0 || InOutVisited > MaxVisited) return;
	InOutVisited++;
	const FString TypeStr = Widget->GetTypeAsString();

	// Find SNiagaraActionWidget and modify its action item directly
	if (TypeStr == TEXT("SNiagaraActionWidget"))
	{
		SNiagaraActionWidgetHack* Hack = reinterpret_cast<SNiagaraActionWidgetHack*>(&Widget.Get());
		if (Hack && Hack->ActionPtr.IsValid())
		{
			FNiagaraMenuAction_Base* Action = Hack->ActionPtr.Get();

			// Avoid re-translating the same action
			if (!GTranslatedActions.Contains(Action))
			{
				FString EnName = Action->DisplayName.ToString();
				FString LookupStr = EnName;
				if (LookupStr.EndsWith(TEXT("*")))
				{
					LookupStr = LookupStr.LeftChop(1);
				}

				if (const FString* ZhName = EnToZh.Find(LookupStr))
				{
					// Save original English name into Keywords for bilingual search
					FText EnKeywords = FText::FromString(EnName);
					if (!Action->Keywords.IsEmpty())
					{
						Action->Keywords = FText::FromString(
							EnName + TEXT(" ") + Action->Keywords.ToString());
					}
					else
					{
						Action->Keywords = EnKeywords;
					}

					// Set DisplayName to Chinese
					Action->DisplayName = FText::FromString(*ZhName);

					// Rebuild the full-text search string
					Action->UpdateFullSearchText();

					OutTranslated++;
				}

				GTranslatedActions.Add(Action);
			}
		}
	}
	// Also translate standalone STextBlocks (e.g. section headers, filter labels)
	else if (TypeStr == TEXT("STextBlock"))
	{
		TSharedPtr<STextBlock> TextBlock = StaticCastSharedRef<STextBlock>(Widget);
		FString CurrentStr = TextBlock->GetText().ToString();
		if (!CurrentStr.IsEmpty() && !ContainsChinese(CurrentStr))
		{
			FString LookupStr = CurrentStr;
			if (LookupStr.EndsWith(TEXT("*")))
			{
				LookupStr = LookupStr.LeftChop(1);
			}
			if (const FString* Zh = EnToZh.Find(LookupStr))
			{
				TextBlock->SetText(FText::FromString(*Zh));
				OutTranslated++;
			}
		}
	}

	FChildren* Children = Widget->GetChildren();
	if (Children)
	{
		for (int32 i = 0; i < Children->Num(); ++i)
		{
			TranslateMenuItem(Children->GetChildAt(i), EnToZh, OutTranslated, InOutVisited, MaxVisited, Depth - 1);
		}
	}
}

static void ScanSmallWindow(TSharedRef<SWindow> Window, const TMap<FString,FString>& EnToZh, int32& OutTotal)
{
	static constexpr int32 MaxWidgets = 500;
	int32 Visited = 0, Translated = 0;
	TranslateMenuItem(Window->GetContent(), EnToZh, Translated, Visited, MaxWidgets);
	OutTotal += Translated;
}

static void OnSlateWindowRendered(SWindow& Window, void*)
{
	if (!FNiagaraCNModule::IsEnabled()) return;
	const TMap<FString, FString>& EnToZh = FNiagaraCNModule::Get().GetDictionary();
	if (EnToZh.Num() == 0) return;
	int32 Dummy = 0;
	ScanSmallWindow(StaticCastSharedRef<SWindow>(Window.AsShared()), EnToZh, Dummy);
}

static bool AddModuleSearchTick(float DeltaTime)
{
	if (!FNiagaraCNModule::IsEnabled()) return true;

	static bool bSubscribed = false;
	if (!bSubscribed && FSlateApplication::IsInitialized())
	{
		if (FSlateRenderer* R = FSlateApplication::Get().GetRenderer())
		{
			R->OnSlateWindowRendered().AddStatic(&OnSlateWindowRendered);
			UE_LOG(LogNiagaraCN, Log, TEXT("AddModule: subscribed to OnSlateWindowRendered"));
		}
		bSubscribed = true;
	}

	const TMap<FString, FString>& EnToZh = FNiagaraCNModule::Get().GetDictionary();
	if (EnToZh.Num() == 0) return true;

	int32 TotalTranslated = 0;
	FSlateApplication& SlateApp = FSlateApplication::Get();

	for (const TSharedRef<SWindow>& Root : SlateApp.GetTopLevelWindows())
	{
		for (const TSharedRef<SWindow>& Child : Root->GetChildWindows())
		{
			ScanSmallWindow(Child, EnToZh, TotalTranslated);
		}
	}

#if !UE_BUILD_SHIPPING
	static int32 TickCount = 0;
	if (TotalTranslated > 0 && TickCount % 120 == 0)
	{
		UE_LOG(LogNiagaraCN, Log, TEXT("AddModule: translated %d module action(s)"), TotalTranslated);
	}
	++TickCount;
#endif

	return true;
}

#undef LOCTEXT_NAMESPACE
