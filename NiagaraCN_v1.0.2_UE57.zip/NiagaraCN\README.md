# Niagara Chinese Translation Companion (Niagara 中文翻译伴侣)

A UE5.5 editor plugin that translates English text in the Niagara Editor UI into Chinese with a single toolbar toggle button.

## Features

- **One-click toggle** — Switch between Chinese and English display in the Niagara editor via toolbar button (Level Editor, Niagara Script Editor, and Niagara System Editor toolbars)
- **Module name translation** — All Niagara module names (e.g., "Add Velocity" → "添加速度")
- **Parameter name translation** — Function input/parameter names within modules
- **Group label translation** — Spawn/Update groups, Render groups, Event Handlers
- **Namespace & type translation** — Particles, Emitter, System, Engine namespaces; data types
- **Data Interface translation** — Skeletal Mesh Data, Static Mesh Data, Grid 2D/3D, etc.
- **Non-invasive** — Does not modify any engine assets. All translation is display-only via the AlternateDisplayName system

## Installation

1. Copy the `NiagaraCN` folder to your project's `Plugins/` directory (or UE5 engine's `Engine/Plugins/FX/` directory)
2. If your project doesn't have C++ modules yet, add an empty C++ class via Editor to enable C++ compilation
3. Recompile your project / regenerate project files
4. Launch the editor — the "中/英" toggle button will appear in the toolbar

## Usage

1. Open any Niagara System or Emitter
2. Click the **中/英** toggle button in the toolbar (highlighted blue when active)
3. All Niagara stack entries (modules, parameters, groups) will display in Chinese
4. Click again to switch back to English

## Supported UE Versions

| Version | Status |
|---------|--------|
| 5.5.x | Tested & fully supported |
| 5.6.x | Compatible (same Niagara Editor API surface) |
| 5.7.x | Compatible |

The plugin avoids `StaticClass()` and `TObjectIterator<T>` (which break on MinimalAPI classes) by using runtime class name checks, `GetClass()` reflection, and `static_cast`. This approach is naturally resilient across engine versions as long as the Niagara Editor's class layouts and exported method signatures remain stable.

## Technical Notes

This plugin uses two translation mechanisms:

1. **FText Localization Pipeline** — An `ILocalizedTextSource` implementation intercepts `LOCTEXT()`-based text at the localization level
2. **AlternateDisplayName System** — Stack entries' alternate display names are set via `UNiagaraStackEditorData` reflection, which the `SNiagaraStackDisplayName` widget already checks before the default display name. Function inputs use `SetSummaryViewDisplayName()` for direct override.

## Limitations

- The "Add Module" menu and the "Details" panel use `FText::FromString()` which bypasses UE's localization pipeline and cannot be intercepted by this plugin
- Translations only affect the Niagara editor UI; runtime behavior and asset data are unchanged

## License

MIT License — see LICENSE file
